MapleStoryAutoLevelUp v16.3 Route Segmenter Smart Bot

Purpose
- Fix v16.2 issue where recorder could save impossible cross-floor actions, for example:
  walk_left start=[143,48] end=[166,172]
- Those wrong anchors caused runner correction to pull the character between floors, causing jump spam, rope confusion, and wall bumping.

Main changes
1. Recorder route segmentation
   - Detects large Y-level changes between action start_pos/end_pos.
   - Classifies them as climb_transition / drop_transition / fall_transition / jump_up_transition.
   - Adds route_state and correction_mode metadata.

2. Unsafe horizontal cross-floor segments are made replay-only
   - If a pure left/right action crosses floors, its end_pos is cleared.
   - Runner will replay the key timing but will not use it as a correction anchor.

3. Runner respects segmented actions
   - correction_mode: replay_only means no pre/post minimap correction.
   - This prevents the bot from dragging the character back to a wrong floor.

4. Small floor settle waits
   - After a floor transition, a short wait is inserted so minimap and collision state can stabilize.

Recommended workflow
1. py -m src.main
2. System / Window / Capture / Minimap checks
3. Smart Route -> Start Smart Route Recorder
4. Manually walk one clean loop, including rope/drop/jump
5. Press F12 to save
6. Check Smart Route
7. Run Smart Bot

Notes
- This version does not try to be more aggressive.
- It makes the route safer by refusing impossible correction anchors.
- If a route still fails, record a slower and cleaner loop, especially around rope/platform transitions.
