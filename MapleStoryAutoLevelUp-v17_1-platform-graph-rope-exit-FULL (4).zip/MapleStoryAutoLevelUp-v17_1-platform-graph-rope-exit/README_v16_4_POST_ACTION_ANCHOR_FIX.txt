# MapleStoryAutoLevelUp v16.4 - Post-action Anchor Fix

這版修正 v16.3 的核心問題：Recorder 會把角色已經到上層的動作，仍然記成下層 anchor。

## 修正內容
- 每個 action 結束後等待短暫 settle，再抓 minimap position 作為 end_pos。
- start_pos 改用 action 開始前最後穩定座標。
- 若 action 期間 y 軸跨樓層，使用 trajectory 最後點修正 end_pos。
- route segmenter 仍保留：跨樓層段標記為 transition / replay_only，不再拿錯誤水平段做校正。

## 使用
```powershell
py -m src.main
```

流程：System/Window/Capture/Minimap check → Smart Route Recorder → 手動走一圈 → F12 → Run Script。

## 觀察重點
錄完後 action_route_check 內不應再大量出現：
- 實際人在上層，但 start/end 都是 [166,172]
- walk_left/walk_right 卻跨很大的 y 樓層差
