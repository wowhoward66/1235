MapleStoryAutoLevelUp v17.1 platform-graph-rope-exit hotfix

Changes in this build:
- Keep the same project/folder naming requested by the user.
- Unified GUI stays as Route Intelligence.
- Jump key is standardized to ALT for route-intent transitions and rope exit.
- Added continuous platform occupancy lock: platform confirmation now requires consecutive samples on the same platform, not just scattered ok samples.
- Added platform center recovery: after rope exit / landing, the bot nudges toward platform center and reconfirms, reducing edge slip and immediate fall.
- jump_up / climb_transition / up_floor_transition are treated as intentional upward transitions, not unknown replay actions.
- drop_transition / fall_transition are treated as intentional downward transitions.

Suggested flow:
1. py -m src.main
2. System / Minimap -> run checks until minimap ok=True
3. Route Intelligence -> Learn Route Intelligence
4. Walk one effective farming loop. Pause briefly on each platform. Press F12 to save.
5. Check Route Intelligence
6. Run Farming Loop
