MapleStoryAutoLevelUp v16.6 Stable Movement Sampling

重點：
- 基於 v16.5 Navigation System。
- 修正 recorder movement sampling：動作結束後依類型等待再取樣。
- walk/jump/rope/drop 使用不同 settle delay。
- 多次 minimap position 取中位數，降低單次偵測飄移。
- 如果 movement action start/end 幾乎沒位移，標記 static_action + replay_only，不讓它污染 navigation graph。

建議測試流程：
1. py -m src.main
2. System / Window / Capture / Minimap Check
3. Smart Route Recorder：錄一圈完整路線，盡量不要站著連按太多無位移鍵。
4. Run Script。
5. 若還卡住，貼 debug/smart_action_runner_status.txt 與 action_route_check 輸出。
