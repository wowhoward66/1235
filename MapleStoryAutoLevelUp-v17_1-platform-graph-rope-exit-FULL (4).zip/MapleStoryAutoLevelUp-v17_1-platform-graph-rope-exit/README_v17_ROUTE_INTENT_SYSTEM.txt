MapleStoryAutoLevelUp v17 Route Intent System

核心改動：
- 不再只錄玩家所有按鍵 raw replay。
- 新增 tools.route_intent_recorder，學習有效 farming path：platform nodes + transition nodes。
- Stable platform detector：停留超過 stable_seconds 才建立平台。
- Transition commit rule：換層後在新平台穩定超過 commit_seconds 才保留轉場。
- Fake transition discard：上樓後立刻掉下來，視為失敗轉場，不放進 navigation graph。
- Controlled movement runner：
  - 一般修正只允許左右走回平台，不把 jump 當修正工具。
  - 只有 route transition 節點才允許跳、上爬、下跳。
  - 到平台後會先確認穩定，再繼續下一步。

建議使用流程：
1. py -m src.main
2. System / Minimap 全部檢查 ok=True
3. Route Intent v17 → Start Route Intent Recorder
4. 手動走一圈真正要刷的路線；進平台後停 1.5 秒以上；不要亂試跳
5. F12 停止
6. Check Route Intent
7. Run Smart Bot

PowerShell：
py -m tools.route_intent_recorder --map_id test_map --window_title "MapleStory Worlds-楓星" --minimap_rect 0,0,245,251 --inner_margin 4
py -m tools.route_intent_check --script scripts/test_map.yaml
py -m tools.run_script --script scripts/test_map.yaml

Debug：
- debug/route_intent_debug.txt
- debug/route_intent_recorder_status.txt
- debug/route_intent_runner_status.txt
