MapleStoryAutoLevelUp v17.1 - Platform Graph + Rope Exit State

重點修正：
1. Rope Exit State
   - 只有在 route intent transition node 附近才允許 up / alt+up / jump。
   - 爬繩到接近上層平台後，會 release up，左右微移，單次跳離繩索。
   - 會確認 platform stable 後才繼續下一步。

2. Platform Graph Learning
   - Route Intent Recorder 不再把所有按鍵當主要路線。
   - 只保留穩定停留平台與成功樓層轉換。
   - 過濾 minimap 假 marker 大跳點。

3. Controlled Movement
   - 一般 correction 只允許左右走回位置，不允許亂跳找繩。
   - jump / rope / drop 只在明確 transition node 執行。

建議流程：
1. py -m src.main
2. System / Minimap 全部檢查 ok
3. Route Intent v17 頁面錄製：走一圈真正刷怪路線
   - 進入平台後停 1.5 秒
   - 爬繩到頂後也停一下
   - 不要測試亂跳
4. F12 停止
5. Run Smart Bot

Debug：
- debug/route_intent_debug.txt
- debug/route_intent_runner_status.txt
- debug/minimap_check.txt
