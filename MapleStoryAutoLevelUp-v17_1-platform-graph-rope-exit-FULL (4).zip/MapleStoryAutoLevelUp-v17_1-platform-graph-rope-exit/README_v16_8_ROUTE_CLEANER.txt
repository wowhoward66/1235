MapleStoryAutoLevelUp v16.8 Route Cleaner

This is a COMPLETE runnable project package based on v16.7 Precision Tracking.

Fix focus:
- Keeps v16.7 subpixel minimap tracking.
- Adds route cleaner after recording and segmentation.
- Removes short no-movement replay_only movement spam.
- Merges tiny waits / repeated short movement noise.
- Preserves floor transitions: climb_transition, jump_up_transition, drop_transition, fall_transition.
- Preserves non-movement skill/attack keys even if they do not move the player.

How to run:
  py -m src.main

Debug files:
  debug/clean_route_debug.txt
  debug/smart_action_route_recorder_status.txt
  debug/smart_action_runner_status.txt
