MapleStoryAutoLevelUp v17.1 - Unified Route Intelligence

This build keeps the project/folder name:
MapleStoryAutoLevelUp-v17_1-platform-graph-rope-exit

Changes:
1. GUI merged ROUTE / V17 SMART ROUTE into one Route Intelligence tab.
2. Primary route flow is Route Intent, not raw action replay.
3. Adaptive platform learning:
   - normal platform stable threshold defaults to 1.2s
   - after rope/drop transition can commit at 0.7s
4. Adaptive transition commit:
   - transitions can be kept after shorter post-transition stability
   - fake transitions are still discarded
5. Route runner keeps controlled movement:
   - no random jumping during correction
   - jump/up/down only at transition nodes
   - rope exit state remains enabled
6. False marker filtering remains enabled.

Recommended flow:
1. py -m src.main
2. System / Minimap -> System Check + Window Check + Capture Check + Minimap Check
3. Route Intelligence -> Learn Route Intelligence
4. Walk one real farming loop.
5. On every true platform, pause briefly. After rope exit/drop landing, pause about 0.7s.
6. Press F12 to save.
7. Route Intelligence -> Check Route Intelligence
8. Route Intelligence -> Run Farming Loop

Debug files:
- debug/route_intent_debug.txt
- debug/route_intent_recorder_status.txt
- debug/route_intent_runner_status.txt
