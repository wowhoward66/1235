MapleStoryAutoLevelUp v16.9 Navigation Lock / Anti-loop

Fixes based on v16.8 logs:
- Prevent navigation from wrapping from late actions back to early actions in the same loop.
- Add anti-loop protection for repeated jump_to targets.
- Add short navigation cooldown after transition/floor_settle nodes.
- Keep v16.8 route cleaner + v16.7 precision tracking.

Expected improvement:
- Stops repeated #6 -> #12 -> #19 -> #6 navigation loops.
- When floor mismatch cannot be resolved safely, it skips forward instead of bouncing forever.

Run:
py -m src.main
