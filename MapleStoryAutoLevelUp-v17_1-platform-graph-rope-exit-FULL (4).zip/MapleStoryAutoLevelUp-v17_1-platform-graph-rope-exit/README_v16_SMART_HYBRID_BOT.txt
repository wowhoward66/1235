# v16 Smart Hybrid Bot

這版從 v15_5 Action Route Stable 升級而來。

## 保留
- window_check
- capture_check
- minimap_check
- action_route_recorder
- run_script

## 移除/不再主推
- timed fallback route
- waypoint route recorder
- waypoint route runner 作為主要流程

## 新增
- smart_action_route mode
- 錄製鍵盤動作時，同步採樣 minimap 玩家座標
- 每個 action 會帶 start_pos / end_pos anchor
- runner 會在 replay 前/後做位置校正

## 原理
純 action replay 會因為 lag、被怪撞、卡平台而跑偏。
v16 不是只照時間按鍵，而是：

1. 播放動作前檢查目前 minimap position
2. 如果離 recorded anchor 太遠，先用 left/right/up/down/alt 做保守校正
3. 播放原本錄下來的跳、爬、下跳、攻擊
4. 長動作後再檢查 end_pos，必要時小幅修正

## 使用
```powershell
py -m src.main
```

或 CLI：
```powershell
py -m tools.action_route_recorder --map_id test_map --window_title "MapleStory Worlds-楓星" --minimap_rect 0,0,245,251
py -m tools.smart_route_check --script scripts/test_map.yaml
py -m tools.run_script --script scripts/test_map.yaml
```
