MapleStoryAutoLevelUp v16.1 Rope Exit Fix

修正重點：
- 保留 v16 smart_action_route。
- 新增 rope_exit_handler：爬繩/梯子到頂後，自動 release up，微移 left/right，再 jump 離開繩索站上平台。
- correction_move 對「目標在上方且 X 接近」改用 hold up 繼續爬，不再一直 up+jump。
- 避免 rope-top 小動作被 pre-correction 過度拉回錯誤 anchor。

建議測試流程：
1. py -m src.main
2. System / Minimap 檢查 ok=True
3. Smart Route 重新錄一圈路線
4. Run Smart Bot

如果還卡繩索頂端：
- 到 scripts/test_map.yaml 裡調：
  rope_exit_directions: ['left','right'] 或 ['right','left']
  rope_exit_hold_seconds: 0.24 -> 0.35
  rope_extra_climb_seconds: 1.1 -> 1.5
