MapleStoryAutoLevelUp v16.7 Precision Tracking

目標：修正 v16.6 仍然把平台左右小位移判定成 replay_only 的問題。

新增/修正：
- Minimap player detector 改為保留 float/subpixel centroid，不只 int 座標。
- Recorder 使用 precise=True 抓取小數 minimap 座標。
- 動作結束後仍保留 v16.6 的 stable sampling，但新增 accumulated path movement。
- 若 net movement 很小但 trajectory path movement 有變化，不再直接丟成 static replay_only。
- 每個 action 加上 movement_debug: net/path/dx/dy，方便判斷錄製品質。
- 保留 v16.5 navigation system 與 v16.6 stable movement sampling。

測試流程：
1. py -m src.main
2. System / Window / Capture / Minimap check
3. Smart Route / Action Route Recorder 錄一圈
4. F12 停止
5. Check script，看 action 是否開始出現 start/end 小數座標與 movement_debug
6. Run Script

觀察重點：
- 如果 walk_left / walk_right 的 movement_debug path 有增加，代表小位移有被記錄。
- 如果大量 action 仍是 replay_only，代表 minimap_rect 可能還是不夠準，或錄製時角色在小地圖上變化太小。
