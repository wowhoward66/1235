from __future__ import annotations
import argparse
from pathlib import Path
import yaml
from modules.route_core.action_schema import validate_action_route
from modules.debug_core.debug_io import write_status


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--script', default='scripts/test_map.yaml')
    args = ap.parse_args()
    path = Path(args.script)
    if not path.is_absolute():
        path = Path.cwd() / path
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    issues = validate_action_route(data)
    actions = data.get('actions') or []
    lines = [f'script={path}', f'mode={data.get("mode")}', f'version={data.get("version")}', f'actions={len(actions)}', f'correction={data.get("action_route",{}).get("correction_enabled")}']
    for i, a in enumerate(actions[:30], 1):
        lines.append(f'#{i}: {a}')
    if len(actions) > 30:
        lines.append(f'... {len(actions)-30} more actions')
    lines += [f'ok={not issues}']
    if issues:
        lines.append('issues:')
        lines.extend(' - ' + x for x in issues)
    text = '\n'.join(lines) + '\n'
    write_status('smart_action_route_check.txt', text)
    print(text, flush=True)

if __name__ == '__main__':
    main()
