from __future__ import annotations
import argparse
from modules.route_core.runner import run_script

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--script', required=True)
    args = ap.parse_args()
    run_script(args.script)
if __name__ == '__main__': main()
