from __future__ import annotations
import argparse, yaml
from pathlib import Path
from modules.debug_core.debug_io import write_status


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--script', default='scripts/test_map.yaml')
    args = ap.parse_args()
    p = Path(args.script)
    if not p.is_absolute():
        p = Path.cwd() / p
    with p.open('r', encoding='utf-8') as f:
        data = yaml.safe_load(f) or {}
    lines = []
    lines.append(f'script={p}')
    lines.append(f'mode={data.get("mode")}')
    lines.append(f'platforms={len(data.get("platforms") or [])}')
    lines.append(f'transitions={len(data.get("transitions") or [])}')
    lines.append(f'sequence={len(data.get("sequence") or [])}')
    for pl in data.get('platforms') or []:
        lines.append(f"PLATFORM {pl.get('id')} y={pl.get('y')} x_range={pl.get('x_range')} duration={pl.get('duration')}")
    for tr in data.get('transitions') or []:
        lines.append(f"TRANSITION {tr.get('id')} {tr.get('type')} {tr.get('from')} -> {tr.get('to')} x={tr.get('x')} key_hint={tr.get('key_hint')}")
    text = '\n'.join(lines) + '\n'
    print(text)
    write_status('route_intent_check.txt', text)

if __name__ == '__main__':
    main()
