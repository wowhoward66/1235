from __future__ import annotations
import argparse
import time
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path
import yaml

from modules.route_core.smart_action import current_position
from modules.route_core.action_schema import normalize_key_name
from modules.debug_core.debug_io import log, write_status
from modules.debug_core.process_lock import ProcessLock


def median(vals: List[float]) -> float:
    if not vals:
        return 0.0
    vals = sorted(float(v) for v in vals)
    return vals[len(vals)//2]


def pos_of(sample: Dict[str, Any]) -> Optional[Tuple[float, float]]:
    p = sample.get('pos')
    if not p:
        return None
    return float(p[0]), float(p[1])


def key_hint(events: List[Dict[str, Any]], start_t: float, end_t: float) -> List[str]:
    keys = []
    for e in events:
        if start_t <= float(e.get('t', 0)) <= end_t:
            k = normalize_key_name(str(e.get('key')))
            if k not in keys and k != 'f12':
                keys.append(k)
    # Keep only movement intent keys; skills are not transition hints.
    return [k for k in keys if k in {'left','right','up','down','alt','space','shift'}]


def segment_stable_platforms(samples: List[Dict[str, Any]], *, y_tolerance: float, stable_seconds: float, post_transition_stable_seconds: float, min_x_span: float, floor_threshold: float) -> List[Dict[str, Any]]:
    if not samples:
        return []
    segs: List[Dict[str, Any]] = []
    cur: List[Dict[str, Any]] = []
    cur_y: Optional[float] = None
    for s in samples:
        p = pos_of(s)
        if not p:
            continue
        if not cur:
            cur = [s]; cur_y = p[1]; continue
        ys = [pos_of(x)[1] for x in cur if pos_of(x)] + [p[1]]
        if max(ys) - min(ys) <= y_tolerance:
            cur.append(s)
            cur_y = median(ys)
        else:
            segs.append({'samples': cur})
            cur = [s]; cur_y = p[1]
    if cur:
        segs.append({'samples': cur})

    platforms = []
    for idx, seg in enumerate(segs):
        pts = [pos_of(s) for s in seg['samples'] if pos_of(s)]
        if len(pts) < 2:
            continue
        t0 = float(seg['samples'][0]['t']); t1 = float(seg['samples'][-1]['t'])
        dur = t1 - t0
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        # Adaptive stable threshold:
        # - normal platform needs stable_seconds
        # - immediately after / before a large floor change, accept shorter stability
        #   so rope-exit platforms can be learned even if the player only pauses briefly.
        prev_y = None
        next_y = None
        if idx > 0:
            prev_pts = [pos_of(s) for s in segs[idx-1]['samples'] if pos_of(s)]
            if prev_pts:
                prev_y = median([q[1] for q in prev_pts])
        if idx + 1 < len(segs):
            next_pts = [pos_of(s) for s in segs[idx+1]['samples'] if pos_of(s)]
            if next_pts:
                next_y = median([q[1] for q in next_pts])
        this_y = median(ys)
        near_transition = (prev_y is not None and abs(this_y - prev_y) >= floor_threshold) or (next_y is not None and abs(next_y - this_y) >= floor_threshold)
        required_stable = min(stable_seconds, post_transition_stable_seconds) if near_transition else stable_seconds
        if dur < required_stable:
            continue
        x0, x1 = min(xs), max(xs)
        if (x1 - x0) < min_x_span:
            # Still a valid standing platform; widen a little for correction.
            cx = median(xs); x0, x1 = cx - min_x_span/2.0, cx + min_x_span/2.0
        platforms.append({
            'id': f'platform_{len(platforms)+1}',
            'y': round(median(ys), 3),
            'x_range': [round(x0, 3), round(x1, 3)],
            'center': [round((x0+x1)/2.0, 3), round(median(ys), 3)],
            'start_t': round(t0, 3),
            'end_t': round(t1, 3),
            'duration': round(dur, 3),
            'sample_count': len(pts),
            'adaptive_stable_required': round(required_stable, 3),
            'near_transition': bool(near_transition),
        })
    return merge_platforms(platforms, y_tol=y_tolerance, x_gap=18.0)


def merge_platforms(platforms: List[Dict[str, Any]], *, y_tol: float, x_gap: float) -> List[Dict[str, Any]]:
    merged: List[Dict[str, Any]] = []
    for p in platforms:
        found = None
        for m in merged:
            xr, mr = p['x_range'], m['x_range']
            same_y = abs(float(p['y']) - float(m['y'])) <= y_tol
            touch_x = not (float(xr[1]) < float(mr[0]) - x_gap or float(xr[0]) > float(mr[1]) + x_gap)
            if same_y and touch_x:
                found = m; break
        if found:
            found['x_range'] = [round(min(float(found['x_range'][0]), float(p['x_range'][0])), 3), round(max(float(found['x_range'][1]), float(p['x_range'][1])), 3)]
            found['y'] = round((float(found['y']) + float(p['y'])) / 2.0, 3)
            found['center'] = [round((float(found['x_range'][0]) + float(found['x_range'][1]))/2.0, 3), found['y']]
            found['duration'] = round(float(found.get('duration',0)) + float(p.get('duration',0)), 3)
            found['end_t'] = max(float(found.get('end_t',0)), float(p.get('end_t',0)))
            found['start_t'] = min(float(found.get('start_t',0)), float(p.get('start_t',0)))
        else:
            merged.append(dict(p))
    for i, p in enumerate(merged, start=1):
        p['id'] = f'platform_{i}'
    return merged


def platform_for_time(platforms: List[Dict[str, Any]], t: float) -> Optional[Dict[str, Any]]:
    candidates = [p for p in platforms if float(p['start_t']) <= t <= float(p['end_t'])]
    if candidates:
        return candidates[0]
    before = [p for p in platforms if float(p['end_t']) <= t]
    after = [p for p in platforms if float(p['start_t']) >= t]
    near = []
    if before:
        near.append(min(before, key=lambda p: abs(float(p['end_t']) - t)))
    if after:
        near.append(min(after, key=lambda p: abs(float(p['start_t']) - t)))
    if not near:
        return None
    return min(near, key=lambda p: min(abs(float(p['start_t']) - t), abs(float(p['end_t']) - t)))


def build_transitions(platforms: List[Dict[str, Any]], events: List[Dict[str, Any]], *, floor_threshold: float, commit_seconds: float, post_transition_stable_seconds: float, fake_discard_seconds: float) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], str]:
    transitions: List[Dict[str, Any]] = []
    sequence: List[Dict[str, Any]] = []
    report = []
    if not platforms:
        return transitions, sequence, 'no platforms\n'
    # Sort by first time seen, build intent sequence.
    ordered = sorted(platforms, key=lambda p: float(p['start_t']))
    sequence.append({'type': 'platform', 'platform': ordered[0]['id'], 'x': ordered[0]['center'][0]})
    for i in range(len(ordered)-1):
        a, b = ordered[i], ordered[i+1]
        dy = float(b['y']) - float(a['y'])
        if abs(dy) < floor_threshold:
            # Same floor farming platform move.
            sequence.append({'type': 'platform', 'platform': b['id'], 'x': b['center'][0]})
            continue
        # Adaptive commit: after a large floor change, shorter confirmed stability is enough.
        required_commit = min(commit_seconds, post_transition_stable_seconds)
        if float(b.get('duration', 0)) < required_commit:
            report.append(f'discard transition {a["id"]}->{b["id"]}: destination not stable duration={b.get("duration")} required={required_commit}')
            continue
        # Fake transition discard: if the next platform returns immediately to source floor, discard.
        if i + 2 < len(ordered):
            c = ordered[i+2]
            immediate_return = abs(float(c['y']) - float(a['y'])) < floor_threshold and (float(c['start_t']) - float(b['start_t']) <= fake_discard_seconds)
            if immediate_return and float(b.get('duration', 0)) < max(commit_seconds * 1.5, 2.5):
                report.append(f'discard fake transition {a["id"]}->{b["id"]}: returned to {c["id"]} too quickly')
                continue
        t0 = float(a['end_t']); t1 = float(b['start_t'])
        hint = key_hint(events, t0, t1)
        ttype = 'rope_up' if dy < 0 else 'drop_down'
        if dy < 0 and ('up' not in hint):
            ttype = 'jump_up'
        if dy > 0 and ('down' not in hint):
            ttype = 'fall_down'
        tx = round((float(a['center'][0]) + float(b['center'][0]))/2.0, 3)
        if dy < 0:
            # Rope x is often close to destination top marker x when climbing.
            tx = round(float(b['center'][0]), 3)
        tr = {
            'id': f'transition_{len(transitions)+1}',
            'type': ttype,
            'from': a['id'],
            'to': b['id'],
            'x': tx,
            'from_y': a['y'],
            'to_y': b['y'],
            'start_t': round(t0, 3),
            'end_t': round(t1, 3),
            'duration': round(max(0.12, t1 - t0), 3),
            'key_hint': hint,
            'commit_seconds': required_commit,
            'needs_jump': bool(dy < 0 and ('alt' in hint or 'space' in hint)),
        }
        transitions.append(tr)
        sequence.append({'type': 'transition', 'transition': tr['id']})
        sequence.append({'type': 'platform', 'platform': b['id'], 'x': b['center'][0]})
    return transitions, sequence, '\n'.join(report) + ('\n' if report else '')


def save_route_intent(map_id: str, script: Dict[str, Any]) -> Path:
    root = Path.cwd()
    scripts_dir = root / 'scripts'
    scripts_dir.mkdir(exist_ok=True)
    path = scripts_dir / f'{map_id}.yaml'
    with path.open('w', encoding='utf-8') as f:
        yaml.safe_dump(script, f, allow_unicode=True, sort_keys=False)
    return path


def main():
    ap = argparse.ArgumentParser(description='v17.1 Route Intent Recorder: learn stable platforms, rope nodes, and committed transitions; reject fake transitions and marker jumps.')
    ap.add_argument('--map_id', default='test_map')
    ap.add_argument('--window_title', default='MapleStory Worlds-楓星')
    ap.add_argument('--minimap_rect', default='0,0,245,251')
    ap.add_argument('--inner_margin', type=int, default=4)
    ap.add_argument('--max_seconds', type=float, default=180.0)
    ap.add_argument('--sample_interval', type=float, default=0.18)
    ap.add_argument('--stable_seconds', type=float, default=1.2)
    ap.add_argument('--post_transition_stable_seconds', type=float, default=0.7)
    ap.add_argument('--commit_seconds', type=float, default=0.8)
    ap.add_argument('--fake_discard_seconds', type=float, default=2.0)
    ap.add_argument('--floor_threshold', type=float, default=42.0)
    ap.add_argument('--platform_y_tolerance', type=float, default=10.0)
    ap.add_argument('--min_x_span', type=float, default=10.0)
    ap.add_argument('--allowed_keys', default='left,right,up,down,alt,space,ctrl,shift,z,x,c,a,s,d,f,1,2,3,4,5,6,q,w,e,r')
    args = ap.parse_args()
    lock = ProcessLock('route_intent_recorder')
    if not lock.acquire():
        msg = 'Route intent recorder is already running. Stop it first.'
        log('[route_intent_recorder] ' + msg)
        print(msg, flush=True)
        return
    try:
        try:
            import keyboard
        except Exception as e:
            raise RuntimeError('keyboard package is required. Run: py -m pip install keyboard') from e
        allowed = {normalize_key_name(k) for k in args.allowed_keys.split(',') if k.strip()}
        samples: List[Dict[str, Any]] = []
        events: List[Dict[str, Any]] = []
        last_good_pos = None
        stopped = False
        t0 = time.time()
        def on_event(ev):
            nonlocal stopped
            key = normalize_key_name(ev.name)
            if key == 'f12' and ev.event_type == 'down':
                stopped = True; return
            if key in allowed:
                events.append({'t': round(time.time()-t0, 4), 'key': key, 'event_type': ev.event_type})
        log(f'[route_intent_recorder] v17.1 start map_id={args.map_id}; F12 stop/save. Walk one effective farming loop. Stop on real platforms > {args.stable_seconds}s; after rope/drop stable > {args.post_transition_stable_seconds}s can commit.')
        hook = keyboard.hook(on_event)
        last_status = -999.0
        try:
            while not stopped and time.time() - t0 <= args.max_seconds:
                elapsed = time.time() - t0
                pos, profile, reason = current_position(args.window_title, args.minimap_rect, args.inner_margin, precise=True)
                if pos:
                    pnow = (float(pos[0]), float(pos[1]))
                    if last_good_pos is not None and abs(pnow[0] - last_good_pos[0]) > 95 and abs(pnow[1] - last_good_pos[1]) < 70:
                        # Detector sometimes locks onto the wrong marker/blob at the minimap edge.
                        # Drop that sample so it cannot create fake platforms/transitions.
                        pass
                    else:
                        samples.append({'t': round(elapsed, 4), 'pos': [round(pnow[0], 3), round(pnow[1], 3)], 'profile': profile})
                        last_good_pos = pnow
                if elapsed - last_status >= 1.0:
                    write_status('route_intent_recorder_status.txt', f'elapsed={elapsed:.1f}\nsamples={len(samples)}\nevents={len(events)}\nF12 stop/save\n')
                    last_status = elapsed
                time.sleep(args.sample_interval)
        finally:
            keyboard.unhook(hook)
        platforms = segment_stable_platforms(samples, y_tolerance=args.platform_y_tolerance, stable_seconds=args.stable_seconds, post_transition_stable_seconds=args.post_transition_stable_seconds, min_x_span=args.min_x_span, floor_threshold=args.floor_threshold)
        transitions, sequence, discard_report = build_transitions(platforms, events, floor_threshold=args.floor_threshold, commit_seconds=args.commit_seconds, post_transition_stable_seconds=args.post_transition_stable_seconds, fake_discard_seconds=args.fake_discard_seconds)
        script = {
            'mode': 'route_intent',
            'version': 'v17_1_platform_graph_rope_exit_unified_adaptive',
            'loop': True,
            'window_title': args.window_title,
            'capture': {'minimap_rect': args.minimap_rect, 'inner_margin': args.inner_margin},
            'route_intent': {
                'stable_seconds': args.stable_seconds,
                'post_transition_stable_seconds': args.post_transition_stable_seconds,
                'commit_seconds': args.commit_seconds,
                'fake_transition_discard': True,
                'floor_threshold': args.floor_threshold,
                'controlled_movement': True,
                'jump_only_at_transition': True,
                'rope_only_near_transition_x': True,
                'rope_exit_state': True,
                'rope_exit_attempts': 2,
                'rope_exit_y_gate': 24,
                'rope_exit_dirs': ['right', 'left'],
                'rope_topup_seconds': 0.45,
                'rope_exit_nudge_seconds': 0.16,
                'rope_exit_settle_seconds': 0.45,
                'walk_x_tolerance': 8,
                'floor_confirm_tolerance': 18,
                'platform_confirm_seconds': 1.2,
                'transition_max_attempts': 2,
                'attack_key': 'ctrl',
                'attack_times_per_platform': 1,
                'keys': {'jump': 'alt'},
            },
            'platforms': platforms,
            'transitions': transitions,
            'sequence': sequence,
            'raw_summary': {'samples': len(samples), 'events': len(events), 'discard_report': discard_report.strip(), 'recorder': 'v17.1_unified_route_intelligence_adaptive'},
        }
        path = save_route_intent(args.map_id, script)
        report = [
            'v17.1 Route Intent Recorder - Unified Route Intelligence + Adaptive Learning',
            f'samples={len(samples)}',
            f'events={len(events)}',
            f'platforms={len(platforms)}',
            f'transitions={len(transitions)}',
            f'sequence={len(sequence)}',
            f'saved={path}',
            '',
            'Platforms:',
        ]
        for p in platforms:
            report.append(f"  {p['id']} y={p['y']} x_range={p['x_range']} duration={p['duration']}")
        report.append('Transitions:')
        for t in transitions:
            report.append(f"  {t['id']} {t['type']} {t['from']} -> {t['to']} x={t['x']} hint={t.get('key_hint')}")
        if discard_report:
            report.append('Discarded:'); report.append(discard_report)
        write_status('route_intent_debug.txt', '\n'.join(report) + '\n')
        write_status('route_intent_recorder_status.txt', f'saved=True\nscript={path}\nplatforms={len(platforms)}\ntransitions={len(transitions)}\nsequence={len(sequence)}\n')
        log(f'[route_intent_recorder] Saved route intent: {path}; platforms={len(platforms)} transitions={len(transitions)} sequence={len(sequence)}')
        print(f'Created route intent -> {path}', flush=True)
    finally:
        lock.release()

if __name__ == '__main__':
    main()
