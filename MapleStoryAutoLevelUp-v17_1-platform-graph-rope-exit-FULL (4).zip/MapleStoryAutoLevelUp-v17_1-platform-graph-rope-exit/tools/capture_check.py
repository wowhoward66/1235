from __future__ import annotations
import argparse
from modules.capture_core.window_capture import capture_window, crop_rect, list_game_windows, CaptureError
from modules.debug_core.debug_io import save_image, write_status

def parse_rect(s):
    if not s: return None
    vals = [int(v.strip()) for v in s.split(',')]
    if len(vals) != 4: raise ValueError('rect must be x,y,w,h')
    return tuple(vals)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--window_title', default='MapleStory Worlds-楓星')
    ap.add_argument('--title_bar_height', type=int, default=0)
    ap.add_argument('--minimap_rect', default='')
    args = ap.parse_args()
    candidates = list_game_windows(args.window_title)
    try:
        frame, win = capture_window(args.window_title, args.title_bar_height)
    except CaptureError as e:
        text = "ERROR: " + str(e) + "\n\nwindow_candidates:\n"
        for w in candidates:
            text += f"usable={w.usable} area={w.area} iconic={w.iconic} visible={w.visible} rect={w.rect} reason={w.reason} title={w.title}\n"
        write_status('capture_check.txt', text)
        print(text)
        return
    save_image('v15_capture_full.png', frame)
    text = f"window={win.title}\nrect={win.rect}\nframe_shape={frame.shape}\nselected_area={win.area}\nwindow_candidates={len(candidates)}\n"
    rect = parse_rect(args.minimap_rect)
    if rect:
        mini = crop_rect(frame, rect)
        save_image('v15_capture_minimap.png', mini)
        text += f"minimap_rect={rect}\nminimap_shape={mini.shape}\n"
    write_status('capture_check.txt', text)
    print(text)
if __name__ == '__main__': main()
