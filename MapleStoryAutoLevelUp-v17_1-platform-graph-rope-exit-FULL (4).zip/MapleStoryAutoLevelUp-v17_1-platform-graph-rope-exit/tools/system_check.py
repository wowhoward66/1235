from __future__ import annotations
import importlib, sys, platform
from modules.debug_core.debug_io import log, write_status

def check_module(name):
    try:
        importlib.import_module(name)
        return True, 'OK'
    except Exception as e:
        return False, str(e)

def main():
    items = []
    items.append(('python', True, sys.version))
    items.append(('platform', True, platform.platform()))
    for m in ['cv2','numpy','PIL','yaml','PySide6','keyboard','pyautogui']:
        ok, msg = check_module(m)
        items.append((m, ok, msg))
    lines = []
    for name, ok, msg in items:
        line = f"{'OK' if ok else 'FAIL'} {name}: {msg}"
        print(line)
        lines.append(line)
    write_status('system_check.txt', '\n'.join(lines))
if __name__ == '__main__': main()
