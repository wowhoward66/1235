from __future__ import annotations
import argparse, json
import cv2
import numpy as np
from modules.capture_core.window_capture import capture_window, crop_rect, CaptureError
from modules.minimap_core.player_detector import detect_player_marker, shrink_rect_image, DEFAULT_PROFILES
from modules.debug_core.debug_io import save_image, write_status

def parse_rect(s):
    vals=[int(v.strip()) for v in s.split(',')]
    if len(vals)!=4: raise ValueError('rect must be x,y,w,h')
    return tuple(vals)

def top_hsv_samples(img, n=12):
    if img is None or img.size == 0: return []
    hsv=cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask=((hsv[:,:,1]>35)&(hsv[:,:,2]>80)).astype(np.uint8)
    vals=hsv[mask>0]
    if vals.size == 0: return []
    q=np.stack([(vals[:,0]//5)*5,(vals[:,1]//32)*32,(vals[:,2]//32)*32],axis=1)
    uniq, counts=np.unique(q, axis=0, return_counts=True)
    order=np.argsort(counts)[::-1][:n]
    return [f"HSV~{tuple(int(x) for x in uniq[i])}: pixels={int(counts[i])}" for i in order]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--window_title', default='MapleStory Worlds-楓星')
    ap.add_argument('--title_bar_height', type=int, default=0)
    ap.add_argument('--minimap_rect', required=True)
    ap.add_argument('--hsv_lower', default='12,60,80')
    ap.add_argument('--hsv_upper', default='45,255,255')
    ap.add_argument('--inner_margin', type=int, default=4)
    args=ap.parse_args()
    try:
        frame, win = capture_window(args.window_title, args.title_bar_height)
        mini = crop_rect(frame, parse_rect(args.minimap_rect))
    except CaptureError as e:
        text = "ok=False\nposition=None\nreason=capture_error: " + str(e) + "\n"
        write_status('minimap_check.txt', text)
        print(text)
        return
    inner, _ = shrink_rect_image(mini, args.inner_margin)
    lower=tuple(int(v) for v in args.hsv_lower.split(',')); upper=tuple(int(v) for v in args.hsv_upper.split(','))
    res=detect_player_marker(mini, lower, upper, inner_margin=args.inner_margin)
    save_image('v15_minimap_raw.png', mini); save_image('v15_minimap_inner.png', inner)
    if res.mask is not None: save_image('v15_minimap_mask.png', res.mask)
    if res.overlay is not None: save_image('v15_minimap_detected.png', res.overlay)
    hsv=cv2.cvtColor(inner, cv2.COLOR_BGR2HSV)
    for name,lo,hi in [('custom',lower,upper)] + DEFAULT_PROFILES:
        mask=cv2.inRange(hsv,np.array(lo,dtype=np.uint8),np.array(hi,dtype=np.uint8))
        save_image(f'v15_minimap_mask_{name}.png', mask)
    top=top_hsv_samples(inner)
    text=(f"ok={res.ok}\nposition={res.position}\narea={res.area}\nprofile={res.profile}\nreason={res.reason}\n"
          f"hsv_lower={lower}\nhsv_upper={upper}\ninner_margin={args.inner_margin}\n"
          "top_hsv_samples:\n  " + "\n  ".join(top) + "\n"
          f"debug_profiles={json.dumps(res.debug.get('profiles', []), ensure_ascii=False)}\n")
    write_status('minimap_check.txt', text)
    print(text)
if __name__ == '__main__': main()
