from __future__ import annotations
import argparse
from modules.capture_core.window_capture import list_game_windows
from modules.debug_core.debug_io import write_status

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--window_title', default='MapleStory Worlds-楓星')
    args=ap.parse_args()
    wins=list_game_windows(args.window_title)
    lines=[f"matched_windows={len(wins)}"]
    for i,w in enumerate(sorted(wins, key=lambda x: x.area, reverse=True), 1):
        lines.append(f"#{i} usable={w.usable} area={w.area} iconic={w.iconic} visible={w.visible} rect={w.rect} reason={w.reason} title={w.title}")
    text="\n".join(lines)+"\n"
    write_status('window_check.txt', text)
    print(text)
if __name__ == '__main__': main()
