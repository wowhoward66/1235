from __future__ import annotations
import argparse
import time
from typing import Dict, List, Any, Optional, Tuple

from modules.route_core.action_schema import save_action_route, normalize_key_name
from modules.route_core.smart_action import current_position
from modules.debug_core.debug_io import log, write_status
from modules.debug_core.process_lock import ProcessLock

DEFAULT_ALLOWED_KEYS = [
    'left', 'right', 'up', 'down', 'alt', 'ctrl', 'space', 'shift',
    'z', 'x', 'c', 'a', 's', 'd', 'f', '1', '2', '3', '4', '5', '6', 'q', 'w', 'e', 'r'
]


def _action_name_for_keys(keys: List[str]) -> str:
    s = set(keys)
    if s == {'up'}: return 'climb_up'
    if s == {'down'}: return 'crouch_or_climb_down'
    if s == {'down', 'alt'} or s == {'down', 'space'}: return 'drop_down'
    if 'alt' in s and 'right' in s: return 'jump_right'
    if 'alt' in s and 'left' in s: return 'jump_left'
    if s == {'right'}: return 'walk_right'
    if s == {'left'}: return 'walk_left'
    if 'ctrl' in s: return 'attack'
    return '+'.join(keys)


def _sample_pos(sample: Dict[str, Any]) -> Optional[List[float]]:
    p = sample.get('pos')
    return [float(p[0]), float(p[1])] if p else None




def _dist(a: Optional[List[float]], b: Optional[List[float]]) -> float:
    if not a or not b:
        return 0.0
    return ((float(a[0]) - float(b[0])) ** 2 + (float(a[1]) - float(b[1])) ** 2) ** 0.5


def _median_pos(points: List[List[float]]) -> Optional[List[float]]:
    """Robust stable minimap position from repeated samples."""
    if not points:
        return None
    xs = sorted(float(p[0]) for p in points)
    ys = sorted(float(p[1]) for p in points)
    mid = len(points) // 2
    return [round(xs[mid], 3), round(ys[mid], 3)]


def _stable_pos_window(samples: List[Dict[str, Any]], start_t: float, end_t: float) -> Optional[List[int]]:
    """Median position from samples inside a time window."""
    pts: List[List[float]] = []
    for s in samples:
        ts = float(s.get('t', 0))
        if float(start_t) <= ts <= float(end_t):
            p = _sample_pos(s)
            if p:
                pts.append(p)
    return _median_pos(pts)


def _settle_for_action(a: Dict[str, Any]) -> float:
    """v16.6 action-specific settle delay after key release."""
    keys = set(_action_keys(a))
    name = str(a.get('name') or '').lower()
    if 'drop' in name or ('down' in keys and ('alt' in keys or 'space' in keys)):
        return 0.75
    if 'jump' in name or 'alt' in keys:
        return 0.65
    if 'climb' in name or 'up' in keys:
        return 0.85
    if 'left' in keys or 'right' in keys:
        return 0.42
    return 0.25


def _stable_after_action(samples: List[Dict[str, Any]], a: Dict[str, Any]) -> Optional[List[int]]:
    """Stable post-action anchor using several minimap samples after action end."""
    end_t = float(a.get('_t_end', 0.0) or 0.0)
    settle = _settle_for_action(a)
    p = _stable_pos_window(samples, end_t + settle, end_t + settle + 0.55)
    if p:
        return p
    return _pos_after(samples, end_t, settle=settle, max_wait=max(1.8, settle + 1.2))

def _nearest_pos(samples: List[Dict[str, Any]], t: float) -> Optional[List[int]]:
    if not samples:
        return None
    best = min(samples, key=lambda s: abs(float(s['t']) - float(t)))
    if abs(float(best['t']) - float(t)) > 1.25:
        return None
    return _sample_pos(best)


def _pos_before(samples: List[Dict[str, Any]], t: float, max_age: float = 1.25) -> Optional[List[int]]:
    """Last stable minimap sample before an action starts.

    v16.4 fix: start anchors should be captured from the last known position *before* the
    key action. Using nearest sample could accidentally grab a future upper-floor sample.
    """
    candidates = [s for s in samples if float(s.get('t', 0)) <= float(t)]
    if not candidates:
        return _nearest_pos(samples, t)
    best = max(candidates, key=lambda s: float(s.get('t', 0)))
    if float(t) - float(best.get('t', 0)) > max_age:
        return _nearest_pos(samples, t)
    return _sample_pos(best)


def _pos_after(samples: List[Dict[str, Any]], t: float, settle: float = 0.28, max_wait: float = 1.6) -> Optional[List[int]]:
    """First stable minimap sample after an action finishes and the character has settled.

    v16.4 core fix: end anchors must come from *after* the action, not from the closest
    sample around key-up. Jump/rope/drop actions often keep moving for a few frames after
    the key event; using nearest key-up sample left many actions stuck on the old floor.
    """
    if not samples:
        return None
    target_t = float(t) + float(settle)
    future = [s for s in samples if float(s.get('t', 0)) >= target_t and float(s.get('t', 0)) <= float(t) + float(max_wait)]
    if future:
        # Use the first post-settle sample. It is less likely to be the stale pre-action floor.
        return _sample_pos(min(future, key=lambda s: float(s.get('t', 0))))
    late = [s for s in samples if float(s.get('t', 0)) >= float(t)]
    if late:
        return _sample_pos(min(late, key=lambda s: float(s.get('t', 0))))
    return _nearest_pos(samples, t)


def _trajectory_between(samples: List[Dict[str, Any]], start: float, end: float, tail: float = 0.6) -> List[List[float]]:
    """Minimap points during and shortly after an action."""
    pts: List[List[float]] = []
    for s in samples:
        ts = float(s.get('t', 0))
        if float(start) <= ts <= float(end) + float(tail):
            p = _sample_pos(s)
            if p:
                pts.append(p)
    return pts



def _trajectory_movement(pts: List[List[float]]) -> float:
    if len(pts) < 2:
        return 0.0
    total = 0.0
    prev = pts[0]
    for p in pts[1:]:
        total += ((float(p[0])-float(prev[0]))**2 + (float(p[1])-float(prev[1]))**2) ** 0.5
        prev = p
    return float(total)

def _net_dxdy(a: Optional[List[float]], b: Optional[List[float]]) -> Tuple[float, float]:
    if not a or not b:
        return 0.0, 0.0
    return float(b[0]) - float(a[0]), float(b[1]) - float(a[1])

def _fix_anchor_from_trajectory(a: Dict[str, Any], pts: List[List[int]], floor_threshold: int = 42) -> Dict[str, Any]:
    """Repair start/end anchors using the action trajectory.

    If the action moved across floors, nearest-key timestamps can miss the true landing point.
    We prefer the last trajectory point for end_pos and the first for start_pos, then annotate
    the route so the runner knows this anchor was post-action captured.
    """
    if not pts:
        return a
    if not a.get('start_pos'):
        a['start_pos'] = pts[0]
    if not a.get('end_pos'):
        a['end_pos'] = pts[-1]
    ys = [int(p[1]) for p in pts]
    if max(ys) - min(ys) >= int(floor_threshold):
        a['trajectory_floor_change'] = True
        # Last observed post-action point is the most reliable anchor for the next action.
        a['end_pos'] = pts[-1]
        a['anchor_method'] = 'v16.4_post_action_trajectory'
    else:
        a.setdefault('anchor_method', 'v16.4_post_action_sample')
    return a


def _compress_events(
    events: List[Dict[str, Any]],
    pos_samples: List[Dict[str, Any]],
    max_gap: float = 0.12,
    min_duration: float = 0.025,
    trim_start_wait: float = 0.5,
) -> List[Dict[str, Any]]:
    if not events:
        return []
    events = sorted(events, key=lambda e: e['t'])
    first = float(events[0]['t'])
    offset = first - min(trim_start_wait, first)
    for e in events:
        e['t'] = max(0.0, float(e['t']) - offset)
    for s in pos_samples:
        s['t'] = max(0.0, float(s['t']) - offset)
    active: Dict[str, float] = {}
    completed: List[Dict[str, Any]] = []
    for e in events:
        key = normalize_key_name(e['key'])
        typ = e['event_type']
        t = float(e['t'])
        if typ == 'down':
            active.setdefault(key, t)
        elif typ == 'up':
            start = active.pop(key, None)
            if start is None: continue
            dur = max(min_duration, t - start)
            completed.append({'key': key, 'start': start, 'duration': dur, 'end': start + dur})
    last_t = float(events[-1]['t'])
    for key, start in active.items():
        dur = max(min_duration, last_t - start)
        completed.append({'key': key, 'start': start, 'duration': dur, 'end': start + dur})
    completed.sort(key=lambda a: a['start'])
    actions: List[Dict[str, Any]] = []
    cursor = 0.0
    i = 0
    while i < len(completed):
        item = completed[i]
        start = float(item['start'])
        if start - cursor > max_gap:
            actions.append({'type': 'wait', 'duration': round(start - cursor, 3), 'start_pos': _pos_after(pos_samples, cursor, settle=0.05, max_wait=0.8), 'end_pos': _pos_before(pos_samples, start), '_t_start': round(cursor, 4), '_t_end': round(start, 4)})
        group = [item]
        j = i + 1
        while j < len(completed) and abs(float(completed[j]['start']) - start) <= max_gap:
            group.append(completed[j]); j += 1
        if len(group) == 1:
            g = group[0]
            typ = 'tap' if float(g['duration']) <= 0.09 else 'hold'
            end = float(g['end'])
            actions.append({
                'type': typ, 'key': g['key'], 'duration': round(float(g['duration']), 3),
                'name': _action_name_for_keys([g['key']]),
                'start_pos': _pos_before(pos_samples, start), 'end_pos': _pos_after(pos_samples, end),
                '_t_start': round(start, 4), '_t_end': round(end, 4),
            })
            cursor = max(cursor, end)
        else:
            keys = [g['key'] for g in group]
            dur = max(float(g['duration']) for g in group)
            end = max(float(g['end']) for g in group)
            actions.append({
                'type': 'combo', 'keys': keys, 'duration': round(dur, 3), 'name': _action_name_for_keys(keys),
                'start_pos': _pos_before(pos_samples, start), 'end_pos': _pos_after(pos_samples, end),
                '_t_start': round(start, 4), '_t_end': round(end, 4),
            })
            cursor = max(cursor, end)
        i = j
    # v16.4: repair anchors after each action using the minimap trajectory, so the route
    # does not keep lower-floor anchors after a rope/jump/drop has already landed elsewhere.
    repaired: List[Dict[str, Any]] = []
    for a in actions:
        if a.get('type') == 'wait':
            repaired.append(a)
            continue
        # Estimate action time span from available anchors by finding the nearest event-like window.
        # We kept no explicit start/end time in the YAML, so attach temporary timing metadata here.
        # Below we use duration with previous cursor-style reconstruction from action order.
        repaired.append(a)

    # v16.6 stable movement sampling: use original event timestamps instead of reconstructing
    # a synthetic timeline. Then wait per action type and median-sample several minimap frames.
    repaired2: List[Dict[str, Any]] = []
    for a in repaired:
        start_t = float(a.get('_t_start', 0.0) or 0.0)
        end_t = float(a.get('_t_end', start_t + float(a.get('duration', 0.0) or 0.0)) or 0.0)
        if a.get('type') == 'wait':
            a['start_pos'] = a.get('start_pos') or _pos_before(pos_samples, start_t)
            a['end_pos'] = a.get('end_pos') or _pos_before(pos_samples, end_t)
            a.pop('_t_start', None); a.pop('_t_end', None)
            repaired2.append(a)
            continue
        before = _pos_before(pos_samples, start_t) or a.get('start_pos')
        after = _stable_after_action(pos_samples, a) or a.get('end_pos')
        a['start_pos'] = before
        a['end_pos'] = after
        pts = _trajectory_between(pos_samples, start_t, end_t, tail=max(0.9, _settle_for_action(a) + 0.55))
        a = _fix_anchor_from_trajectory(a, pts)
        keys = set(_action_keys(a))
        movement_like = bool(keys & {'left', 'right', 'up', 'down', 'alt', 'space'})
        net_move = _dist(a.get('start_pos'), a.get('end_pos'))
        path_move = _trajectory_movement(pts)
        dx, dy = _net_dxdy(a.get('start_pos'), a.get('end_pos'))
        a['movement_debug'] = {'net': round(net_move, 3), 'path': round(path_move, 3), 'dx': round(dx, 3), 'dy': round(dy, 3)}
        # v16.7: do not throw away small platform movement. Minimap marker is tiny;
        # subpixel + accumulated path movement is more trustworthy than integer net distance.
        if movement_like and net_move < 0.65 and path_move < 1.50:
            a['static_action'] = True
            a['correction_mode'] = 'replay_only'
            a['anchor_method'] = 'v16.7_static_replay_only'
        else:
            a.setdefault('anchor_method', 'v16.8_route_cleaner')
        a.pop('_t_start', None); a.pop('_t_end', None)
        repaired2.append(a)

    merged: List[Dict[str, Any]] = []
    for a in repaired2:
        a.pop('_t_start', None); a.pop('_t_end', None)
        if a.get('type') == 'wait' and float(a.get('duration', 0)) < 0.08:
            continue
        merged.append(a)
    return merged


def _ydiff(a: Optional[List[int]], b: Optional[List[int]]) -> int:
    if not a or not b:
        return 0
    return int(b[1]) - int(a[1])


def _xdiff(a: Optional[List[int]], b: Optional[List[int]]) -> int:
    if not a or not b:
        return 0
    return int(b[0]) - int(a[0])


def _action_keys(a: Dict[str, Any]) -> List[str]:
    if a.get('type') == 'combo':
        return [normalize_key_name(k) for k in (a.get('keys') or [])]
    if a.get('key'):
        return [normalize_key_name(a.get('key'))]
    return []


def _classify_floor_transition(a: Dict[str, Any], floor_threshold: int) -> Optional[str]:
    """Return route_state when an action crosses floors and must not be treated as normal walk.

    v16.3 fix: previous recorder could create impossible segments like
    walk_left start=[143,48] end=[166,172]. That made the smart runner think a horizontal
    walk could change floors, then correction started pulling the player into walls/ropes.
    """
    start = a.get('start_pos')
    end = a.get('end_pos')
    if not start or not end:
        return None
    dy = _ydiff(start, end)  # positive = moved down on minimap, negative = moved up
    if abs(dy) < int(floor_threshold):
        return None
    keys = set(_action_keys(a))
    name = str(a.get('name') or '').lower()
    if dy < 0:  # moved upward
        if 'up' in keys or 'climb' in name or ('alt' in keys and 'up' in keys):
            return 'climb_transition'
        if 'alt' in keys or 'space' in keys:
            return 'jump_up_transition'
        return 'up_floor_transition'
    # moved downward
    if 'down' in keys and ('alt' in keys or 'space' in keys):
        return 'drop_transition'
    if 'down' in keys:
        return 'climb_down_transition'
    return 'fall_transition'


def _segment_actions_by_floor(
    actions: List[Dict[str, Any]],
    *,
    floor_threshold: int = 42,
    impossible_walk_threshold: int = 36,
) -> List[Dict[str, Any]]:
    """Annotate and sanitize actions using minimap start/end anchors.

    This does not try to invent complex navigation. It makes the route *safe* by preventing
    impossible cross-floor actions from being used as correction anchors.
    """
    out: List[Dict[str, Any]] = []
    for idx, src in enumerate(actions):
        a = dict(src)
        state = _classify_floor_transition(a, floor_threshold)
        if state:
            raw_name = str(a.get('name') or a.get('type') or 'action')
            a['route_state'] = state
            a['floor_transition'] = True
            a['correction_mode'] = 'replay_only'
            a['raw_name'] = raw_name
            a['raw_end_pos'] = a.get('end_pos')
            a['name'] = state
            a['segment_note'] = f'v16.3 segmented cross-floor action; original={raw_name}'
            # Do not allow a horizontal-only action to claim it ends on another floor.
            # The next reliable action/anchor will re-acquire position. This avoids "pull back to wrong floor".
            keys = set(_action_keys(a))
            horizontal_only = keys and keys.issubset({'left', 'right'})
            if horizontal_only and abs(_ydiff(a.get('start_pos'), a.get('end_pos'))) >= impossible_walk_threshold:
                a['end_pos'] = None
                a['segment_note'] += '; end_pos cleared because horizontal-only cross-floor segment is unsafe'
            out.append(a)
            # Add a tiny settle after real floor transitions so minimap/collision can stabilize.
            if state in {'climb_transition', 'jump_up_transition', 'drop_transition', 'fall_transition', 'climb_down_transition'}:
                out.append({
                    'type': 'wait',
                    'duration': 0.18,
                    'name': 'floor_settle',
                    'route_state': 'floor_settle',
                    'correction_mode': 'none',
                    'start_pos': a.get('raw_end_pos') or a.get('end_pos'),
                    'end_pos': a.get('raw_end_pos') or a.get('end_pos'),
                })
            continue
        out.append(a)
    # Remove back-to-back tiny waits introduced by segmentation/noise.
    merged: List[Dict[str, Any]] = []
    for a in out:
        if merged and a.get('type') == 'wait' and merged[-1].get('type') == 'wait':
            merged[-1]['duration'] = round(float(merged[-1].get('duration', 0)) + float(a.get('duration', 0)), 3)
            merged[-1]['end_pos'] = a.get('end_pos') or merged[-1].get('end_pos')
        else:
            merged.append(a)
    return merged



# v16.8 route cleaner: remove noisy no-movement replay-only actions and merge tiny spam.
def _same_floor_static(a: Dict[str, Any], threshold: float = 0.75) -> bool:
    if a.get('floor_transition') or a.get('route_state') in {'climb_transition','jump_up_transition','up_floor_transition','drop_transition','fall_transition','climb_down_transition','floor_settle'}:
        return False
    sp, ep = a.get('start_pos'), a.get('end_pos')
    if not sp or not ep:
        return False
    try:
        return _dist(sp, ep) <= threshold
    except Exception:
        return False


def _is_movement_key_action(a: Dict[str, Any]) -> bool:
    keys = set(_action_keys(a))
    # Movement/navigation keys only. Skill keys such as ctrl/z/x/c/a/s/d/f/1-6/q/w/e/r are preserved.
    return bool(keys) and keys.issubset({'left','right','up','down','alt','space'})


def _clean_route_actions(actions: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], str]:
    """Clean route noise after segmentation."""
    cleaned: List[Dict[str, Any]] = []
    removed: List[str] = []
    merged_waits = 0
    kept_transitions = 0
    kept_skills = 0
    for idx, src in enumerate(actions, start=1):
        a = dict(src)
        state = str(a.get('route_state') or '')
        is_transition = state in {'climb_transition','jump_up_transition','up_floor_transition','drop_transition','fall_transition','climb_down_transition','floor_settle'} or bool(a.get('floor_transition'))
        if is_transition:
            kept_transitions += 1
            cleaned.append(a)
            continue
        if a.get('type') == 'wait':
            dur = float(a.get('duration', 0) or 0)
            if dur < 0.08:
                removed.append(f'#{idx} remove tiny wait {dur:.3f}s')
                continue
            if cleaned and cleaned[-1].get('type') == 'wait':
                cleaned[-1]['duration'] = round(float(cleaned[-1].get('duration', 0) or 0) + dur, 3)
                cleaned[-1]['end_pos'] = a.get('end_pos') or cleaned[-1].get('end_pos')
                merged_waits += 1
            else:
                cleaned.append(a)
            continue
        is_move = _is_movement_key_action(a)
        is_static = _same_floor_static(a) or bool(a.get('static_action'))
        dur = float(a.get('duration', 0) or 0)
        if not is_move:
            kept_skills += 1
            cleaned.append(a)
            continue
        if is_static and str(a.get('correction_mode') or '') == 'replay_only' and dur <= 1.25:
            removed.append(f'#{idx} remove static movement {a.get("name") or a.get("key") or a.get("type")} dur={dur:.3f} start={a.get("start_pos")} end={a.get("end_pos")}')
            continue
        if cleaned and is_move and cleaned[-1].get('correction_mode') == 'replay_only' and a.get('correction_mode') == 'replay_only':
            prev = cleaned[-1]
            if (prev.get('name') == a.get('name') and _same_floor_static(prev) and is_static and float(prev.get('duration',0) or 0) + dur <= 1.8):
                prev['duration'] = round(float(prev.get('duration',0) or 0) + dur, 3)
                prev['end_pos'] = a.get('end_pos') or prev.get('end_pos')
                prev['cleaner_note'] = 'v16.8 merged repeated replay_only movement'
                removed.append(f'#{idx} merge repeated {a.get("name")} into previous')
                continue
        cleaned.append(a)
    report = []
    report.append('v16.8 Route Cleaner')
    report.append(f'input_actions={len(actions)}')
    report.append(f'output_actions={len(cleaned)}')
    report.append(f'removed_or_merged={len(removed)}')
    report.append(f'merged_waits={merged_waits}')
    report.append(f'kept_transitions={kept_transitions}')
    report.append(f'kept_skill_or_attack_actions={kept_skills}')
    report.append('')
    report.extend(removed[:300])
    if len(removed) > 300:
        report.append(f'... {len(removed)-300} more')
    return cleaned, '\n'.join(report) + '\n'

def main():
    ap = argparse.ArgumentParser(description='Record smart keyboard actions + minimap anchors for MapleStory routes.')
    ap.add_argument('--map_id', default='test_map')
    ap.add_argument('--window_title', default='MapleStory Worlds-楓星')
    ap.add_argument('--minimap_rect', default='0,0,245,251')
    ap.add_argument('--inner_margin', type=int, default=4)
    ap.add_argument('--allowed_keys', default=','.join(DEFAULT_ALLOWED_KEYS))
    ap.add_argument('--max_seconds', type=float, default=180.0)
    ap.add_argument('--playback_speed', type=float, default=1.0)
    ap.add_argument('--min_actions', type=int, default=2)
    ap.add_argument('--position_sample_interval', type=float, default=0.25)
    args = ap.parse_args()
    try:
        lock = ProcessLock('action_route_recorder')
        lock.acquire() or (_ for _ in ()).throw(RuntimeError('Action recorder is already running. Stop the current recorder first.'))
    except RuntimeError as e:
        log(f'[smart_recorder] {e}')
        print(str(e), flush=True)
        return
    try:
        allowed = {normalize_key_name(k) for k in args.allowed_keys.split(',') if k.strip()}
        try:
            import keyboard
        except Exception as e:
            raise RuntimeError('keyboard package is required for action recorder. Run: py -m pip install keyboard') from e
        raw_events: List[Dict[str, Any]] = []
        pos_samples: List[Dict[str, Any]] = []
        t0 = time.time()
        stopped = False
        last_status = -999.0
        last_pos_sample = -999.0
        def on_event(ev):
            nonlocal stopped
            key = normalize_key_name(ev.name)
            if key == 'f12' and ev.event_type == 'down':
                stopped = True
                return
            if key not in allowed:
                return
            raw_events.append({'key': key, 'event_type': ev.event_type, 't': time.time() - t0})
        log(f'[smart_recorder] Start map_id={args.map_id}; F12 stop/save. Record one full loop: walk, jump, rope, drop, attack.')
        log('[smart_recorder] v16.8 records with precision tracking plus route cleaner.')
        hook = keyboard.hook(on_event)
        try:
            while not stopped and (time.time() - t0) <= args.max_seconds:
                elapsed = time.time() - t0
                if elapsed - last_pos_sample >= args.position_sample_interval:
                    pos, profile, reason = current_position(args.window_title, args.minimap_rect, args.inner_margin, precise=True)
                    if pos:
                        pos_samples.append({'t': elapsed, 'pos': [round(float(pos[0]), 3), round(float(pos[1]), 3)], 'profile': profile})
                    last_pos_sample = elapsed
                if elapsed - last_status >= 1.0:
                    write_status('smart_action_route_recorder_status.txt', f'elapsed={elapsed:.1f}\nevents={len(raw_events)}\npos_samples={len(pos_samples)}\nF12 stop/save\n')
                    last_status = elapsed
                time.sleep(0.04)
        finally:
            keyboard.unhook(hook)
        actions_raw = _compress_events(raw_events, pos_samples)
        actions_segmented = _segment_actions_by_floor(actions_raw, floor_threshold=42)
        actions, clean_report = _clean_route_actions(actions_segmented)
        write_status('clean_route_debug.txt', clean_report)
        if len(actions) < int(args.min_actions):
            msg = (
                f'raw_events={len(raw_events)}\n'
                f'actions={len(actions)}\n'
                f'pos_samples={len(pos_samples)}\n'
                'segmented=True\n'
                'anchor_fix=v16.8_route_cleaner\n'
                'saved=False\n'
                'reason=too_few_actions\n'
            )
            write_status('smart_action_route_recorder_status.txt', msg)
            log(f'[smart_recorder] Too few actions: raw_events={len(raw_events)} actions={len(actions)} pos_samples={len(pos_samples)}. Route not saved.')
            print('Smart action route not saved. See debug/smart_action_route_recorder_status.txt', flush=True)
            return

        save_path = save_action_route(
            args.map_id,
            actions,
            window_title=args.window_title,
            minimap_rect=args.minimap_rect,
            inner_margin=args.inner_margin,
            playback_speed=args.playback_speed,
            smart=True,
        )
        msg = (
            f'raw_events={len(raw_events)}\n'
            f'actions={len(actions)}\n'
            f'pos_samples={len(pos_samples)}\n'
            'segmented=True\n'
            'anchor_fix=v16.8_route_cleaner\n'
            'saved=True\n'
            f'script={save_path}\n'
        )
        write_status('smart_action_route_recorder_status.txt', msg)
        log(f'[smart_recorder] Saved smart action route: {save_path}; raw_events={len(raw_events)} actions={len(actions)} pos_samples={len(pos_samples)} segmented=True cleaned=True anchor_fix=v16.8_route_cleaner')
        print(f'Created smart action route -> {save_path}', flush=True)
    finally:
        lock.release()

if __name__ == '__main__':
    main()
