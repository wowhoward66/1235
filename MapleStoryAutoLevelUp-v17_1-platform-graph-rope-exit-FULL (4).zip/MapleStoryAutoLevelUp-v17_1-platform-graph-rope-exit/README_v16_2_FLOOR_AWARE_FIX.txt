MapleStoryAutoLevelUp v16.2 Floor-aware Smart Hybrid Bot

修正目的：
- 修正 v16.1 在繩索/平台附近亂跳、撞牆、一直嘗試回到錯誤 anchor 的問題。
- 針對 MapleStory Worlds 多層平台，加入 floor-aware correction。

本版重點：
1. Smart correction 加入樓層判斷：
   - 如果目前 y 與目標 y 差太大，且不是明確的爬繩/上跳 action，會跳過校正。
   - 避免人在上層卻被校正回下層，或人在下層卻一直跳牆找上層。

2. rope_exit 只在真正「往上跨樓層」後觸發：
   - 必須 start_pos -> end_pos 有足夠 vertical gain 才會觸發。
   - 不再對 down/crouch、小跳、普通 up tap 亂觸發。

3. 禁止 correction 亂跳脫卡：
   - 預設不再用 correction 的 jump spam 解卡。
   - 避免一直跳、撞牆、像找繩索一樣亂動。

4. 保留 v16 smart_action_route：
   - 仍然使用 action replay + minimap anchors。
   - 只是讓 anchor correction 更保守、更懂樓層。

使用方式：
1. py -m src.main
2. System / Window / Capture / Minimap 檢查
3. Smart Route Recorder 錄完整一圈
4. F12 停止
5. Smart Route Check
6. Run Smart Bot

建議：
- 錄路線時，爬繩上平台後，請明確按一下左/右離開繩索，再走到平台上。
- 不要在繩索頂端停太久，避免錄到太多 ambiguous anchors。
