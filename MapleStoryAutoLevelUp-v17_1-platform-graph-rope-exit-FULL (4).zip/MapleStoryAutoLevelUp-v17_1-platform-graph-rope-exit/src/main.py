from __future__ import annotations
import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QLabel, QLineEdit, QTabWidget, QDoubleSpinBox, QSpinBox
from PySide6.QtCore import QProcess

ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable

class V17Gui(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('MapleStoryAutoLevelUp v17.1 Route Intelligence Unified')
        self.resize(1040, 760)
        self.procs = []
        self.active_modules = {}
        main = QVBoxLayout(self)
        self.tabs = QTabWidget(); main.addWidget(self.tabs)
        self.log = QTextEdit(); self.log.setReadOnly(True); main.addWidget(self.log, 1)
        self._build_system_tab()
        self._build_route_intelligence_tab()
        self._build_run_tab()

    def add_line(self, s):
        self.log.append(str(s))

    def run_module(self, module, args=None):
        args = args or []
        singleton = module in {'tools.action_route_recorder', 'tools.route_intent_recorder', 'tools.run_script'}
        if singleton:
            for m, proc in list(self.active_modules.items()):
                if proc.state() != QProcess.NotRunning and (m == module or module == 'tools.run_script' or m == 'tools.run_script'):
                    self.add_line(f'SKIP: {module} already has an active helper running: {m}. Press Stop All first if needed.')
                    return
        cmd = [PYTHON, '-m', module] + args
        self.add_line('RUN: ' + ' '.join(cmd))
        p = QProcess(self)
        p.setWorkingDirectory(str(ROOT))
        p.readyReadStandardOutput.connect(lambda p=p: self.add_line(bytes(p.readAllStandardOutput()).decode('utf-8','replace')))
        p.readyReadStandardError.connect(lambda p=p: self.add_line(bytes(p.readAllStandardError()).decode('utf-8','replace')))
        def _finished(code, status, p=p, module=module):
            self.add_line(f'FINISHED {module}: code={code}')
            if self.active_modules.get(module) is p:
                self.active_modules.pop(module, None)
        p.finished.connect(_finished)
        p.start(cmd[0], cmd[1:])
        self.procs.append(p)
        if singleton:
            self.active_modules[module] = p

    def _build_system_tab(self):
        tab = QWidget(); lay = QVBoxLayout(tab)
        self.win_title = QLineEdit('MapleStory Worlds-楓星')
        self.rect = QLineEdit('0,0,245,251')
        self.inner_margin = QSpinBox(); self.inner_margin.setRange(0, 30); self.inner_margin.setValue(4)
        lay.addWidget(QLabel('Window title token')); lay.addWidget(self.win_title)
        lay.addWidget(QLabel('Minimap rect: x,y,w,h')); lay.addWidget(self.rect)
        lay.addWidget(QLabel('Inner margin')); lay.addWidget(self.inner_margin)
        row = QHBoxLayout()
        for text, mod, extra in [
            ('System Check', 'tools.system_check', []),
            ('Window Check', 'tools.window_check', ['--window_title', self.win_title.text]),
            ('Capture Check', 'tools.capture_check', ['--window_title', self.win_title.text, '--minimap_rect', self.rect.text]),
            ('Minimap Player Check', 'tools.minimap_check', ['--window_title', self.win_title.text, '--minimap_rect', self.rect.text, '--inner_margin', lambda: str(self.inner_margin.value())]),
        ]:
            btn = QPushButton(text)
            def make_cb(mod=mod, extra=extra):
                def cb():
                    args=[]
                    for x in extra:
                        args.append(x() if callable(x) else x)
                    self.run_module(mod, args)
                return cb
            btn.clicked.connect(make_cb())
            row.addWidget(btn)
        lay.addLayout(row)
        lay.addWidget(QLabel('先確認 minimap_check ok=True，再到 Route Intelligence 學路線。'))
        self.tabs.addTab(tab, 'System / Minimap')

    def _build_route_intelligence_tab(self):
        tab = QWidget(); lay = QVBoxLayout(tab)
        self.map_id = QLineEdit('test_map')
        self.script_path = QLineEdit('scripts/test_map.yaml')
        self.intent_max_seconds = QDoubleSpinBox(); self.intent_max_seconds.setRange(5.0, 600.0); self.intent_max_seconds.setValue(180.0)
        self.intent_stable_seconds = QDoubleSpinBox(); self.intent_stable_seconds.setRange(0.4, 5.0); self.intent_stable_seconds.setSingleStep(0.1); self.intent_stable_seconds.setValue(1.2)
        self.intent_post_transition_stable = QDoubleSpinBox(); self.intent_post_transition_stable.setRange(0.3, 3.0); self.intent_post_transition_stable.setSingleStep(0.1); self.intent_post_transition_stable.setValue(0.7)
        self.intent_commit_seconds = QDoubleSpinBox(); self.intent_commit_seconds.setRange(0.3, 6.0); self.intent_commit_seconds.setSingleStep(0.1); self.intent_commit_seconds.setValue(0.8)
        self.intent_sample_interval = QDoubleSpinBox(); self.intent_sample_interval.setRange(0.08, 0.6); self.intent_sample_interval.setSingleStep(0.02); self.intent_sample_interval.setValue(0.18)
        lay.addWidget(QLabel('Route Intelligence：合併 ROUTE / V17 SMART ROUTE。主線只使用 Route Intent，不再把 raw key replay 當主要路線。'))
        lay.addWidget(QLabel('Map ID')); lay.addWidget(self.map_id)
        lay.addWidget(QLabel('Script path')); lay.addWidget(self.script_path)
        lay.addWidget(QLabel('Max learn seconds')); lay.addWidget(self.intent_max_seconds)
        lay.addWidget(QLabel('Stable platform seconds（一般平台停留門檻）')); lay.addWidget(self.intent_stable_seconds)
        lay.addWidget(QLabel('Post-transition stable seconds（爬繩/掉落後較短門檻）')); lay.addWidget(self.intent_post_transition_stable)
        lay.addWidget(QLabel('Transition commit seconds（換層後保留門檻）')); lay.addWidget(self.intent_commit_seconds)
        lay.addWidget(QLabel('Position sample interval')); lay.addWidget(self.intent_sample_interval)
        row = QHBoxLayout()
        learn = QPushButton('Learn Route Intelligence')
        learn.clicked.connect(lambda: self.run_module('tools.route_intent_recorder', [
            '--map_id', self.map_id.text(), '--window_title', self.win_title.text(), '--minimap_rect', self.rect.text(),
            '--inner_margin', str(self.inner_margin.value()), '--max_seconds', str(self.intent_max_seconds.value()),
            '--sample_interval', str(self.intent_sample_interval.value()), '--stable_seconds', str(self.intent_stable_seconds.value()),
            '--post_transition_stable_seconds', str(self.intent_post_transition_stable.value()),
            '--commit_seconds', str(self.intent_commit_seconds.value())
        ]))
        check = QPushButton('Check Route Intelligence')
        check.clicked.connect(lambda: self.run_module('tools.route_intent_check', ['--script', self.script_path.text()]))
        run = QPushButton('Run Farming Loop')
        run.clicked.connect(lambda: self.run_module('tools.run_script', ['--script', self.script_path.text()]))
        stop = QPushButton('Stop All')
        stop.clicked.connect(self.stop_all)
        row.addWidget(learn); row.addWidget(check); row.addWidget(run); row.addWidget(stop); lay.addLayout(row)
        lay.addWidget(QLabel('錄製方式：走真正刷怪路線；每個有效平台停一下；爬繩到頂/下跳落地後停約 0.7 秒即可。系統會自動學 platform / transition / rope exit。'))
        lay.addWidget(QLabel('進階備援：若要測舊 smart_action_route，可用 tools.action_route_recorder 指令；GUI 不再另開分頁避免混淆。'))
        self.tabs.addTab(tab, 'Route Intelligence')

    def _build_run_tab(self):
        tab = QWidget(); lay = QVBoxLayout(tab)
        lay.addWidget(QLabel('Run 已整合到 Route Intelligence。此頁只保留緊急停止與 debug 提醒。'))
        stop = QPushButton('Stop All Child Processes')
        stop.clicked.connect(self.stop_all)
        lay.addWidget(stop)
        lay.addWidget(QLabel('主要流程：System / Minimap -> Route Intelligence: Learn -> Check -> Run.'))
        self.tabs.addTab(tab, 'Debug / Stop')

    def stop_all(self):
        for p in self.procs:
            if p.state() != QProcess.NotRunning:
                p.terminate()
                if not p.waitForFinished(800):
                    p.kill()
        self.active_modules.clear()
        self.add_line('Stop requested for all child processes.')


def main():
    app = QApplication(sys.argv)
    w = V17Gui(); w.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
