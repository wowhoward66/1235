def test_imports():
    import modules.capture_core.window_capture
    import modules.minimap_core.player_detector
    import modules.route_core.script_schema
    import modules.route_core.runner
    import modules.combat_core.combat_loop
    import modules.input_core.keyboard_driver
