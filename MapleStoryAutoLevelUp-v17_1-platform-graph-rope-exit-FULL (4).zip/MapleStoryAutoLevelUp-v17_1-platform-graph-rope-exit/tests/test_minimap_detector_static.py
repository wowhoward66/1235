import numpy as np, cv2
from modules.minimap_core.player_detector import detect_player_marker

def test_detector_on_synthetic_yellow_dot():
    img = np.zeros((100,100,3), dtype=np.uint8)
    cv2.circle(img, (50,50), 4, (0,220,255), -1)
    res = detect_player_marker(img)
    assert res.ok
    assert abs(res.position[0]-50) <= 2
    assert abs(res.position[1]-50) <= 2
