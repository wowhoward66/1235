from modules.route_core.action_schema import validate_action_route

def test_action_route_schema_ok():
    data = {'mode': 'action_route', 'actions': [{'type': 'hold', 'key': 'right', 'duration': 1.0}]}
    assert validate_action_route(data) == []
