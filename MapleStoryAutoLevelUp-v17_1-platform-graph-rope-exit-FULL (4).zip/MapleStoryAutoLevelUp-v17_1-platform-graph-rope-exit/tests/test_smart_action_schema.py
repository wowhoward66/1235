from modules.route_core.action_schema import validate_action_route

def test_smart_action_route_valid():
    s={'mode':'smart_action_route','actions':[{'type':'hold','key':'left','duration':1.0,'start_pos':[1,2],'end_pos':[3,2]}]}
    assert validate_action_route(s)==[]
