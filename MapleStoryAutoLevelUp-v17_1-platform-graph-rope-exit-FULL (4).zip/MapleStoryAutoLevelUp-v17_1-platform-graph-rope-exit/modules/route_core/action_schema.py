from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any
import yaml

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / 'scripts'

VALID_KEYS = {
    'left', 'right', 'up', 'down', 'alt', 'space', 'ctrl', 'shift', 'z', 'x', 'c', 'a', 's', 'd', 'f',
    '1', '2', '3', '4', '5', '6', 'q', 'w', 'e', 'r'
}

def safe_map_id(map_id: str) -> str:
    text = str(map_id or 'test_map').strip().replace(' ', '_')
    keep = []
    for ch in text:
        keep.append(ch if (ch.isalnum() or ch in '_-') else '_')
    return ''.join(keep) or 'test_map'

def normalize_key_name(key: str) -> str:
    k = str(key or '').lower().strip()
    aliases = {
        '左': 'left', '右': 'right', '上': 'up', '下': 'down',
        'control': 'ctrl', 'left ctrl': 'ctrl', 'right ctrl': 'ctrl',
        'left alt': 'alt', 'right alt': 'alt',
        ' ': 'space', 'escape': 'esc',
    }
    return aliases.get(k, k)

def save_action_route(
    map_id: str,
    actions: List[Dict[str, Any]],
    *,
    window_title: str = 'MapleStory Worlds-楓星',
    minimap_rect: str = '0,0,245,251',
    inner_margin: int = 4,
    loop: bool = True,
    playback_speed: float = 1.0,
    smart: bool = True,
) -> Path:
    mid = safe_map_id(map_id)
    data = {
        'version': 'v16.6-stable-movement-sampling-smart-hybrid-bot',
        'map_id': mid,
        'mode': 'smart_action_route' if smart else 'action_route',
        'loop': bool(loop),
        'window_title': window_title,
        'capture': {
            'minimap_rect': minimap_rect,
            'inner_margin': int(inner_margin),
            'title_bar_height': 0,
        },
        'action_route': {
            'playback_speed': float(playback_speed),
            'correction_enabled': True,
            'x_tolerance': 10,
            'y_tolerance': 16,
            'max_anchor_distance': 70,
            'max_correction_seconds': 2.5,
            'correction_step_seconds': 0.12,
            'post_correct_min_duration': 0.45,
            'release_between_actions': True,
            'rope_exit_enabled': True,
            'rope_exit_x_tolerance': 18,
            'rope_exit_y_tolerance': 14,
            'rope_align_x_tolerance': 18,
            'rope_vertical_correction': True,
            'rope_extra_climb_seconds': 1.1,
            'rope_exit_tries': 2,
            'rope_exit_directions': ['left', 'right'],
            'rope_exit_tap_seconds': 0.10,
            'rope_exit_jump_seconds': 0.18,
            'rope_exit_hold_seconds': 0.24,
            'rope_exit_min_vertical_gain': 36,
            'floor_y_threshold': 44,
            'route_segmenter_enabled': True,
            'floor_transition_y_threshold': 42,
            'post_action_anchor_fix': True,
            'anchor_settle_seconds': 0.28,
            'navigation_enabled': True,
            'navigation_lookahead': 14,
            'navigation_lookbehind': 4,
            'navigation_max_hops_per_loop': 8,
            'navigation_skip_mismatched_floor_actions': True,
            'replay_only_segments_no_correction': True,
            'disable_correction_jump_unstick': True,
            'floor_aware_stop_on_stuck': True,
            'rope_pre_correct_skip_distance': 145,
            'rope_exit_fall_guard_y': 32,
            'keys': {
                'jump': 'alt',
                'attack': 'ctrl',
                'left': 'left',
                'right': 'right',
                'up': 'up',
                'down': 'down',
            },
            'notes': 'v16.6 stable movement sampling: post-action anchors use action-specific settle delay and median minimap samples; static movement actions are replay-only.',
        },
        'actions': actions,
    }
    SCRIPTS.mkdir(exist_ok=True)
    path = SCRIPTS / f'{mid}.yaml'
    with path.open('w', encoding='utf-8') as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
    return path

def validate_action_route(script: Dict[str, Any]) -> List[str]:
    issues: List[str] = []
    if script.get('mode') not in {'action_route', 'smart_action_route'}:
        issues.append(f"mode is {script.get('mode')!r}, expected action_route or smart_action_route")
    actions = script.get('actions') or []
    if not isinstance(actions, list) or not actions:
        issues.append('actions is empty')
        return issues
    for i, a in enumerate(actions):
        if not isinstance(a, dict):
            issues.append(f'action[{i}] is not an object')
            continue
        typ = a.get('type')
        if typ == 'hold':
            if not a.get('key'):
                issues.append(f'action[{i}] hold missing key')
            if float(a.get('duration', 0)) <= 0:
                issues.append(f'action[{i}] hold duration <= 0')
        elif typ == 'tap':
            if not a.get('key'):
                issues.append(f'action[{i}] tap missing key')
        elif typ == 'wait':
            if float(a.get('duration', 0)) < 0:
                issues.append(f'action[{i}] wait duration < 0')
        elif typ == 'combo':
            keys = a.get('keys') or []
            if not keys:
                issues.append(f'action[{i}] combo missing keys')
        elif typ == 'marker':
            pass
        else:
            issues.append(f'action[{i}] unknown type {typ!r}')
    return issues
