from __future__ import annotations
import time
from pathlib import Path

from modules.route_core.script_schema import load_script
from modules.input_core.keyboard_driver import hold, press, combo, release_all
from modules.combat_core.combat_loop import attack
from modules.debug_core.debug_io import log, write_status
from modules.capture_core.window_capture import capture_window, crop_rect, CaptureError
from modules.minimap_core.player_detector import detect_player_marker
from modules.route_core.smart_action import run_smart_action
from modules.route_core.route_intent import run_route_intent


def _run_timed(script: dict, path: str):
    route = script.get('timed_route') or []
    combat = script.get('combat') or {}
    attack_key = combat.get('attack_key', 'ctrl')
    interval = float(combat.get('attack_interval', 0.12))
    loop = bool(script.get('loop', True))
    try:
        while True:
            for step in route:
                key = step.get('key')
                seconds = float(step.get('seconds', 1.0))
                times = int(step.get('attack_times', 0))
                log(f"Move {key} {seconds}s; attack_times={times}")
                hold(key, seconds)
                attack(attack_key, times, interval)
            if not loop:
                break
    except KeyboardInterrupt:
        log('Runner stopped by Ctrl+C')


def _parse_rect(text: str):
    vals = [int(v.strip()) for v in str(text).split(',')]
    if len(vals) != 4:
        raise ValueError('minimap_rect must be x,y,w,h')
    return tuple(vals)


def _current_position(window_title: str, minimap_rect: str, inner_margin: int):
    frame, _ = capture_window(window_title, 0)
    mini = crop_rect(frame, _parse_rect(minimap_rect))
    res = detect_player_marker(mini, inner_margin=inner_margin)
    if not res.ok or not res.position:
        raise RuntimeError(res.reason or 'player marker not found')
    return res.position, res.profile


def _tap_jump():
    # Default jump key in many MapleStory setups is alt. Users can change later in YAML if needed.
    press('alt', 0.05)


def _move_toward(dx: int, dy: int, step_seconds: float, x_tol: int, y_tol: int):
    # Horizontal movement is the safest base layer for MapleStory; vertical routing is intentionally conservative.
    if abs(dx) > x_tol:
        hold('right' if dx > 0 else 'left', step_seconds)
    elif dy < -y_tol:
        # Target is above current marker in minimap coordinates. Try a small jump only, no ladder logic yet.
        _tap_jump()
    elif dy > y_tol:
        # Target is below. A short down tap is safer than holding down forever.
        press('down', 0.04)
    else:
        time.sleep(0.05)


def _run_waypoint(script: dict, path: str):
    window_title = script.get('window_title', 'MapleStory Worlds-楓星')
    cap = script.get('capture') or {}
    route_cfg = script.get('route') or {}
    combat = script.get('combat') or {}
    waypoints = script.get('waypoints') or []
    if len(waypoints) < 2:
        raise RuntimeError(f'waypoint_route needs at least 2 waypoints. Got {len(waypoints)}')
    minimap_rect = cap.get('minimap_rect', '0,0,245,251')
    inner_margin = int(cap.get('inner_margin', 4))
    x_tol = int(route_cfg.get('x_tolerance', 7))
    y_tol = int(route_cfg.get('y_tolerance', 12))
    wp_tol = int(route_cfg.get('waypoint_tolerance', 8))
    step_seconds = float(route_cfg.get('move_step_seconds', 0.18))
    max_stuck_seconds = float(route_cfg.get('max_stuck_seconds', 3.0))
    attack_key = combat.get('attack_key', 'ctrl')
    attack_times = int(combat.get('attack_times', 1))
    attack_interval = float(combat.get('attack_interval', 0.12))
    attack_every_waypoint = bool(combat.get('attack_every_waypoint', True))
    loop = bool(script.get('loop', True))
    idx = 0
    last_pos = None
    last_move_time = time.time()
    log(f'Waypoint runner start: {path}; waypoints={len(waypoints)}; rect={minimap_rect}')
    try:
        while True:
            target = waypoints[idx]
            try:
                pos, profile = _current_position(window_title, minimap_rect, inner_margin)
            except Exception as e:
                log(f'[waypoint_runner] marker/capture warning: {e}')
                time.sleep(0.4)
                continue
            dx = int(target[0]) - int(pos[0])
            dy = int(target[1]) - int(pos[1])
            dist = (dx * dx + dy * dy) ** 0.5
            status = f'idx={idx}/{len(waypoints)-1} pos={pos} target={target} dx={dx} dy={dy} dist={dist:.1f} profile={profile}'
            write_status('waypoint_runner_status.txt', status + '\n')
            log('[waypoint_runner] ' + status)
            if dist <= wp_tol or (abs(dx) <= x_tol and abs(dy) <= y_tol):
                if attack_every_waypoint:
                    attack(attack_key, attack_times, attack_interval)
                idx += 1
                if idx >= len(waypoints):
                    if loop:
                        idx = 0
                    else:
                        break
                continue
            if last_pos and abs(pos[0] - last_pos[0]) <= 1 and abs(pos[1] - last_pos[1]) <= 1:
                if time.time() - last_move_time > max_stuck_seconds:
                    log('[waypoint_runner] possible stuck; applying jump+nudge')
                    _tap_jump()
                    hold('right' if dx > 0 else 'left', 0.22)
                    last_move_time = time.time()
            else:
                last_move_time = time.time()
            last_pos = pos
            _move_toward(dx, dy, step_seconds, x_tol, y_tol)
    except KeyboardInterrupt:
        log('Waypoint runner stopped by Ctrl+C')



def _run_action(script: dict, path: str):
    actions = script.get('actions') or []
    cfg = script.get('action_route') or {}
    loop = bool(script.get('loop', True))
    playback_speed = max(0.1, float(cfg.get('playback_speed', 1.0)))
    if not actions:
        raise RuntimeError('action_route has no actions. Record it first with tools.action_route_recorder.')
    log(f'Action route runner start: {path}; actions={len(actions)}; speed={playback_speed}; loop={loop}')
    try:
        while True:
            for i, a in enumerate(actions):
                typ = a.get('type')
                name = a.get('name', '')
                duration = max(0.0, float(a.get('duration', 0.05))) / playback_speed
                if typ == 'wait':
                    log(f'[action_runner] #{i+1}/{len(actions)} wait {duration:.3f}s')
                    time.sleep(duration)
                elif typ == 'tap':
                    key = a.get('key')
                    log(f'[action_runner] #{i+1}/{len(actions)} tap {key} {duration:.3f}s {name}')
                    press(key, max(0.02, duration))
                elif typ == 'hold':
                    key = a.get('key')
                    log(f'[action_runner] #{i+1}/{len(actions)} hold {key} {duration:.3f}s {name}')
                    hold(key, duration)
                elif typ == 'combo':
                    keys = a.get('keys') or []
                    log(f'[action_runner] #{i+1}/{len(actions)} combo {keys} {duration:.3f}s {name}')
                    combo(keys, duration)
                elif typ == 'marker':
                    log(f'[action_runner] #{i+1}/{len(actions)} marker {a}')
                else:
                    log(f'[action_runner] skip unknown action: {a}')
                write_status('action_runner_status.txt', f'idx={i}\ntotal={len(actions)}\naction={a}\n')
            if not loop:
                break
    except KeyboardInterrupt:
        log('Action route runner stopped by Ctrl+C')
    finally:
        release_all()


def run_script(path: str):
    script = load_script(path)
    mode = script.get('mode')
    log(f"Runner start: {path}, mode={mode}")
    if mode == 'timed_fallback':
        return _run_timed(script, path)
    if mode == 'waypoint_route':
        return _run_waypoint(script, path)
    if mode == 'action_route':
        return _run_action(script, path)
    if mode == 'smart_action_route':
        return run_smart_action(script, path)
    if mode == 'route_intent':
        return run_route_intent(script, path)
    raise RuntimeError(f"Unsupported script mode: {mode}")
