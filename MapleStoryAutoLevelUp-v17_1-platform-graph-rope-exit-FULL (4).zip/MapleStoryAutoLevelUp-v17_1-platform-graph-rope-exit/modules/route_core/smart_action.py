from __future__ import annotations
import time
from typing import Any, Dict, List, Optional, Tuple

from modules.capture_core.window_capture import capture_window, crop_rect
from modules.minimap_core.player_detector import detect_player_marker
from modules.input_core.keyboard_driver import hold, press, combo, release_all
from modules.debug_core.debug_io import log, write_status
from modules.route_core.navigation import find_same_floor_entry, should_abort_for_floor_mismatch


def parse_rect(text: str) -> Tuple[int, int, int, int]:
    vals = [int(v.strip()) for v in str(text).split(',')]
    if len(vals) != 4:
        raise ValueError('minimap_rect must be x,y,w,h')
    return tuple(vals)  # type: ignore[return-value]


def current_position(window_title: str, minimap_rect: str, inner_margin: int, *, precise: bool = False) -> Tuple[Optional[Tuple[float, float]], str, str]:
    try:
        frame, _ = capture_window(window_title, 0)
        mini = crop_rect(frame, parse_rect(minimap_rect))
        res = detect_player_marker(mini, inner_margin=inner_margin)
        if res.ok and res.position:
            if precise:
                return (float(res.position[0]), float(res.position[1])), str(res.profile or ''), 'ok'
            pi = res.position_int or (int(round(res.position[0])), int(round(res.position[1])))
            return (int(pi[0]), int(pi[1])), str(res.profile or ''), 'ok'
        return None, str(res.profile or ''), str(res.reason or 'marker_not_found')
    except Exception as e:
        return None, '', f'capture_error:{e}'


def dist(a, b) -> float:
    if not a or not b:
        return 999999.0
    return ((int(a[0]) - int(b[0])) ** 2 + (int(a[1]) - int(b[1])) ** 2) ** 0.5


def _keys_of_action(a: Dict[str, Any]) -> List[str]:
    if a.get('type') == 'combo':
        return [str(k) for k in (a.get('keys') or [])]
    if a.get('key'):
        return [str(a.get('key'))]
    return []


def _is_rope_or_climb_action(a: Dict[str, Any]) -> bool:
    name = str(a.get('name') or '').lower()
    keys = set(_keys_of_action(a))
    if 'climb' in name or 'up+' in name or '+up' in name:
        return True
    # In this project, rope/platform climbing commonly records as alt+up, up+alt, or up+space.
    if 'up' in keys and (a.get('type') in {'hold', 'combo'}):
        return True
    return False


def _same_floor(a, b, threshold: int = 38) -> bool:
    if not a or not b:
        return False
    return abs(int(a[1]) - int(b[1])) <= int(threshold)


def _is_upward_transition(start_pos, end_pos, min_gain: int) -> bool:
    if not start_pos or not end_pos:
        return False
    return int(start_pos[1]) - int(end_pos[1]) >= int(min_gain)


def _should_floor_skip(now, target, cfg: Dict[str, Any], action: Dict[str, Any]) -> bool:
    """Avoid pulling the character across floors with blind correction.

    If the character is already on an upper/lower platform and the next recorded anchor is on a
    very different y-level, horizontal correction will cause wall-bumping/jump spam. Only explicit
    vertical/rope actions may attempt cross-floor movement.
    """
    if not now or not target:
        return False
    floor_y = int(cfg.get('floor_y_threshold', 44))
    dy = abs(int(now[1]) - int(target[1]))
    if dy <= floor_y:
        return False
    return not _is_rope_or_climb_action(action)


def _infer_exit_directions(a: Dict[str, Any], next_action: Optional[Dict[str, Any]], cfg: Dict[str, Any]) -> List[str]:
    dirs: List[str] = []
    start = a.get('start_pos')
    end = a.get('end_pos')
    nxt_start = (next_action or {}).get('start_pos')
    nxt_end = (next_action or {}).get('end_pos')
    # Prefer the direction the recorded path moved after reaching rope top.
    base = end or start
    for target in (nxt_start, nxt_end):
        if base and target and abs(int(target[0]) - int(base[0])) >= int(cfg.get('rope_exit_min_dx_hint', 3)):
            dirs.append('right' if int(target[0]) > int(base[0]) else 'left')
            break
    # If no position hint, use the next explicit action key.
    if next_action:
        keys = _keys_of_action(next_action)
        if 'right' in keys:
            dirs.append('right')
        if 'left' in keys:
            dirs.append('left')
    defaults = cfg.get('rope_exit_directions') or ['left', 'right']
    if isinstance(defaults, str):
        defaults = [x.strip() for x in defaults.split(',') if x.strip()]
    for d in defaults:
        if d in {'left', 'right'} and d not in dirs:
            dirs.append(d)
    return dirs[:2] or ['left', 'right']


def rope_exit_handler(
    *,
    window_title: str,
    minimap_rect: str,
    inner_margin: int,
    target: Optional[List[int] | Tuple[int, int]],
    cfg: Dict[str, Any],
    action: Dict[str, Any],
    next_action: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Try to leave rope/ladder after reaching the top platform.

    MapleStory-style maps often require a tiny left/right + jump after climbing. Pure timing replay
    can stay attached to the rope even when the minimap says the character is almost at the platform.
    This helper is intentionally small and conservative.
    """
    if not bool(cfg.get('rope_exit_enabled', True)):
        return {'ok': False, 'reason': 'rope_exit_disabled'}
    if not target:
        return {'ok': False, 'reason': 'no_target'}
    target = [int(target[0]), int(target[1])]
    jump_key = str(cfg.get('keys', {}).get('jump', 'alt'))
    x_tol = int(cfg.get('rope_exit_x_tolerance', 18))
    y_tol = int(cfg.get('rope_exit_y_tolerance', 14))
    climb_extra = float(cfg.get('rope_extra_climb_seconds', 1.1))
    exit_tap = float(cfg.get('rope_exit_tap_seconds', 0.10))
    exit_jump = float(cfg.get('rope_exit_jump_seconds', 0.18))
    exit_hold = float(cfg.get('rope_exit_hold_seconds', 0.24))
    tries = int(cfg.get('rope_exit_tries', 2))

    release_all()
    log(f'[rope_exit] begin target={target} action={action.get("name", action.get("type"))}')

    # If still slightly below the top anchor, climb a little more before trying to exit.
    t0 = time.time()
    while time.time() - t0 < climb_extra:
        pos, profile, status = current_position(window_title, minimap_rect, inner_margin)
        if not pos:
            time.sleep(0.08)
            continue
        dx = target[0] - pos[0]
        dy = target[1] - pos[1]
        if abs(dx) <= x_tol and dy < -y_tol:
            hold('up', 0.18)
            release_all()
            continue
        break

    directions = _infer_exit_directions(action, next_action, cfg)
    before, profile, status = current_position(window_title, minimap_rect, inner_margin)
    last = before
    for attempt in range(max(1, tries)):
        for d in directions:
            release_all()
            # Small nudge off rope, then jump/side-hop to land on the platform lip.
            press(d, exit_tap)
            combo([d, jump_key], exit_jump)
            hold(d, exit_hold)
            release_all()
            time.sleep(0.08)
            pos, profile, status = current_position(window_title, minimap_rect, inner_margin)
            log(f'[rope_exit] attempt={attempt+1} dir={d} before={before} after={pos} status={status}')
            if not pos:
                continue
            last = pos
            # Consider success if we moved horizontally away from rope x or got near the recorded top anchor.
            moved_x = before is not None and abs(pos[0] - before[0]) >= int(cfg.get('rope_exit_success_dx', 4))
            near_top = abs(pos[0] - target[0]) <= x_tol and abs(pos[1] - target[1]) <= max(y_tol, 18)
            not_fallen = pos[1] <= target[1] + int(cfg.get('rope_exit_fall_guard_y', 32))
            if (moved_x or near_top) and not_fallen:
                return {'ok': True, 'before': before, 'after': pos, 'target': target, 'dir': d, 'reason': 'rope_exit'}
    return {'ok': False, 'before': before, 'after': last, 'target': target, 'dirs': directions, 'reason': 'rope_exit_failed'}


def correction_move(
    *,
    window_title: str,
    minimap_rect: str,
    inner_margin: int,
    target: List[int] | Tuple[int, int],
    cfg: Dict[str, Any],
    reason: str,
) -> Dict[str, Any]:
    """Small state-correction layer before/after action replay.

    v16.1 adds rope-aware vertical correction: if the target is almost directly above,
    hold UP to continue climbing instead of repeatedly doing jump+up.
    """
    enabled = bool(cfg.get('correction_enabled', True))
    if not enabled or not target:
        return {'ok': False, 'reason': 'disabled'}
    x_tol = int(cfg.get('x_tolerance', 10))
    y_tol = int(cfg.get('y_tolerance', 16))
    max_seconds = float(cfg.get('max_correction_seconds', 2.5))
    step = float(cfg.get('correction_step_seconds', 0.12))
    jump_key = str(cfg.get('keys', {}).get('jump', 'alt'))
    rope_x_tol = int(cfg.get('rope_align_x_tolerance', 18))
    t0 = time.time()
    last_pos = None
    stuck_count = 0
    loops = 0
    while time.time() - t0 <= max_seconds:
        loops += 1
        pos, profile, status = current_position(window_title, minimap_rect, inner_margin)
        if not pos:
            time.sleep(0.12)
            continue
        dx = int(target[0]) - int(pos[0])
        dy = int(target[1]) - int(pos[1])
        if abs(dx) <= x_tol and abs(dy) <= y_tol:
            return {'ok': True, 'pos': pos, 'target': target, 'loops': loops, 'profile': profile, 'reason': reason}
        if last_pos and abs(pos[0]-last_pos[0]) <= 1 and abs(pos[1]-last_pos[1]) <= 1:
            stuck_count += 1
        else:
            stuck_count = 0
        last_pos = pos

        if abs(dx) > x_tol:
            hold('right' if dx > 0 else 'left', step)
        elif dy < -y_tol:
            if abs(dx) <= rope_x_tol and bool(cfg.get('rope_vertical_correction', True)):
                # Target is above and x is aligned: likely rope/ladder. Continue climbing.
                hold('up', max(step, 0.16))
            else:
                combo(['up', jump_key], min(0.16, step + 0.04))
        elif dy > y_tol:
            press('down', 0.04)
        if stuck_count >= 8:
            # v16.2: do not jump-spam during correction. A single tiny jump may help, then give up soon.
            if not bool(cfg.get('disable_correction_jump_unstick', True)):
                press(jump_key, 0.05)
            stuck_count = 0
            if bool(cfg.get('floor_aware_stop_on_stuck', True)):
                break
    pos, profile, status = current_position(window_title, minimap_rect, inner_margin)
    return {'ok': False, 'pos': pos, 'target': target, 'loops': loops, 'profile': profile, 'reason': f'timeout:{reason}:{status}'}


def run_smart_action(script: Dict[str, Any], path: str):
    actions: List[Dict[str, Any]] = script.get('actions') or []
    cfg: Dict[str, Any] = script.get('action_route') or {}
    cap: Dict[str, Any] = script.get('capture') or {}
    window_title = script.get('window_title', 'MapleStory Worlds-楓星')
    minimap_rect = cap.get('minimap_rect', '0,0,245,251')
    inner_margin = int(cap.get('inner_margin', 4))
    loop = bool(script.get('loop', True))
    playback_speed = max(0.1, float(cfg.get('playback_speed', 1.0)))
    correction_enabled = bool(cfg.get('correction_enabled', True))
    release_between = bool(cfg.get('release_between_actions', True))
    max_anchor_dist = float(cfg.get('max_anchor_distance', 70.0))
    rope_exit_enabled = bool(cfg.get('rope_exit_enabled', True))
    if not actions:
        raise RuntimeError('smart_action_route has no actions. Record it first with Action Route Recorder.')
    log(f'Smart action runner v16.9 navigation-lock start: {path}; actions={len(actions)}; speed={playback_speed}; loop={loop}; correction={correction_enabled}; rope_exit={rope_exit_enabled}; navigation=True; anti_loop=True')
    nav_enabled = bool(cfg.get('navigation_enabled', True))
    nav_lookahead = int(cfg.get('navigation_lookahead', 14))
    nav_lookbehind = int(cfg.get('navigation_lookbehind', 0))
    floor_threshold = int(cfg.get('floor_y_threshold', 44))
    nav_no_wrap = bool(cfg.get('navigation_no_wrap', True))
    nav_loop_limit = int(cfg.get('navigation_repeat_target_limit', 2))
    nav_cooldown_seconds = float(cfg.get('navigation_cooldown_after_jump', 0.55))
    try:
        while True:
            i = 0
            nav_hops = 0
            nav_jump_counts = {}
            nav_forbidden = set()
            nav_cooldown_until = 0.0
            while i < len(actions):
                a = actions[i]
                typ = a.get('type')
                name = a.get('name', '')
                duration = max(0.0, float(a.get('duration', 0.05))) / playback_speed
                start_pos = a.get('start_pos')
                end_pos = a.get('end_pos')
                next_action = actions[i + 1] if i + 1 < len(actions) else None
                # v16.5 Navigation System: if the character is on a different floor than the
                # current linear action, jump to a nearby same-floor route node instead of
                # blindly executing walk/jump and crashing into walls.
                if nav_enabled and start_pos and typ in {'hold', 'combo', 'tap'}:
                    nav_now, nav_profile, nav_reason = current_position(window_title, minimap_rect, inner_margin)
                    # v16.9: after a navigation jump/transition, give minimap and character physics
                    # a short cooldown before allowing another floor jump. This prevents
                    # #6 -> #12 -> #19 -> #6 oscillation on rope/platform edges.
                    nav_in_cooldown = time.time() < nav_cooldown_until
                    if (not nav_in_cooldown) and should_abort_for_floor_mismatch(nav_now, start_pos, a, floor_threshold=floor_threshold):
                        target_idx = find_same_floor_entry(
                            actions, i, nav_now,
                            floor_threshold=floor_threshold,
                            lookahead=nav_lookahead,
                            lookbehind=nav_lookbehind,
                            allow_wrap=(not nav_no_wrap),
                            forbidden=nav_forbidden,
                        )
                        max_hops = int(cfg.get('navigation_max_hops_per_loop', 8))
                        if target_idx is not None and target_idx != i and nav_hops < max_hops:
                            nav_jump_counts[target_idx] = nav_jump_counts.get(target_idx, 0) + 1
                            if nav_jump_counts[target_idx] > nav_loop_limit:
                                nav_forbidden.add(target_idx)
                                log(f'[navigation] anti_loop block target=#{target_idx+1}/{len(actions)} count={nav_jump_counts[target_idx]}; skip current action')
                                write_status('navigation_status.txt', f'anti_loop_block=1\nidx={i+1}\npos={nav_now}\ntarget={start_pos}\nblocked_jump_to={target_idx+1}\n')
                                i += 1
                                nav_cooldown_until = time.time() + nav_cooldown_seconds
                                continue
                            log(f'[navigation] floor_mismatch idx={i+1} pos={nav_now} target={start_pos} profile={nav_profile} -> jump_to=#{target_idx+1}/{len(actions)}')
                            write_status('navigation_status.txt', f'floor_mismatch_idx={i+1}\npos={nav_now}\ntarget={start_pos}\njump_to={target_idx+1}\nanti_loop_count={nav_jump_counts[target_idx]}\n')
                            i = target_idx
                            nav_hops += 1
                            nav_cooldown_until = time.time() + nav_cooldown_seconds
                            continue
                        else:
                            log(f'[navigation] floor_mismatch idx={i+1} pos={nav_now} target={start_pos}; no safe entry, skip action')
                            i += 1
                            nav_cooldown_until = time.time() + nav_cooldown_seconds
                            continue
                correction_mode = str(a.get('correction_mode') or 'auto')
                route_state = str(a.get('route_state') or '')
                floor_transition = bool(a.get('floor_transition', False))
                allow_correction = correction_mode not in {'none', 'replay_only'} and not floor_transition
                pre = None
                # Correct to the recorded anchor before long or positional actions.
                # v16.3: never use impossible cross-floor replay-only segments as correction anchors.
                if correction_enabled and allow_correction and start_pos and typ in {'hold', 'combo'}:
                    now, profile, reason = current_position(window_title, minimap_rect, inner_margin)
                    d = dist(now, start_pos) if now else 999999.0
                    if _should_floor_skip(now, start_pos, cfg, a):
                        # Already on another platform/floor. Do not spam horizontal correction/jump.
                        pre = {'ok': True, 'pos': now, 'target': start_pos, 'profile': profile, 'reason': 'floor_skip_pre'}
                    # Do not over-correct tiny rope-top actions; replay them first, then rope_exit handles landing.
                    elif d > max_anchor_dist and not (_is_rope_or_climb_action(a) and d <= float(cfg.get('rope_pre_correct_skip_distance', 145.0))):
                        pre = correction_move(window_title=window_title, minimap_rect=minimap_rect, inner_margin=inner_margin, target=start_pos, cfg=cfg, reason=f'pre#{i+1}')
                    else:
                        pre = {'ok': True, 'pos': now, 'target': start_pos, 'profile': profile, 'reason': 'near_anchor_or_rope_skip'}
                log(f'[smart_runner] #{i+1}/{len(actions)} {typ} {name} state={route_state} mode={correction_mode} duration={duration:.3f} start={start_pos} end={end_pos} pre={pre}')
                if typ == 'wait':
                    time.sleep(duration)
                elif typ == 'tap':
                    press(a.get('key'), max(0.02, duration))
                elif typ == 'hold':
                    hold(a.get('key'), duration)
                elif typ == 'combo':
                    combo(a.get('keys') or [], duration)
                elif typ == 'marker':
                    pass
                else:
                    log(f'[smart_runner] skip unknown action: {a}')
                if release_between:
                    release_all()

                rope_exit = None
                # Only detach from rope after a real upward floor transition. Do not trigger rope_exit
                # on down/crouch actions or small up/jump taps, because that caused random jumping/wall bumps.
                if rope_exit_enabled and correction_mode != 'replay_only' and typ in {'hold', 'combo'} and _is_rope_or_climb_action(a) and start_pos and end_pos:
                    vertical_gain = int(start_pos[1]) - int(end_pos[1])
                    if vertical_gain >= int(cfg.get('rope_exit_min_vertical_gain', 36)):
                        rope_exit = rope_exit_handler(
                            window_title=window_title,
                            minimap_rect=minimap_rect,
                            inner_margin=inner_margin,
                            target=end_pos,
                            cfg=cfg,
                            action=a,
                            next_action=next_action,
                        )

                post = None
                # After major movement actions, do a light correction to the recorded end anchor.
                # For rope actions, rope_exit_handler does the post correction; avoid fighting it.
                if (not rope_exit) and correction_enabled and allow_correction and end_pos and typ in {'hold', 'combo'} and float(a.get('duration', 0)) >= float(cfg.get('post_correct_min_duration', 0.45)):
                    now2, profile2, reason2 = current_position(window_title, minimap_rect, inner_margin)
                    if _should_floor_skip(now2, end_pos, cfg, a):
                        post = {'ok': True, 'pos': now2, 'target': end_pos, 'profile': profile2, 'reason': 'floor_skip_post'}
                    else:
                        post = correction_move(window_title=window_title, minimap_rect=minimap_rect, inner_margin=inner_margin, target=end_pos, cfg=cfg, reason=f'post#{i+1}')
                status = f'idx={i+1}\ntotal={len(actions)}\naction={a}\npre={pre}\nrope_exit={rope_exit}\npost={post}\n'
                write_status('smart_action_runner_status.txt', status)
                # v16.9: lock navigation briefly after explicit vertical transitions/settle nodes.
                if route_state in {'fall_transition', 'drop_transition', 'up_floor_transition', 'jump_up_transition', 'climb_transition', 'floor_settle'} or floor_transition:
                    nav_cooldown_until = time.time() + max(nav_cooldown_seconds, float(cfg.get('navigation_transition_lock_seconds', 1.15)))
                i += 1
            if not loop:
                break
    except KeyboardInterrupt:
        log('Smart action runner stopped by Ctrl+C')
    finally:
        release_all()
