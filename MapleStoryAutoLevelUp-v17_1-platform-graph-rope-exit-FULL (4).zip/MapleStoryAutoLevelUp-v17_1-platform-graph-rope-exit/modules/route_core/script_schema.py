from __future__ import annotations
from pathlib import Path
from typing import List, Tuple, Any
import yaml

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / 'scripts'

def _safe_map_id(map_id: str) -> str:
    text = str(map_id or 'test_map').strip().replace(' ', '_')
    keep = []
    for ch in text:
        keep.append(ch if (ch.isalnum() or ch in '_-') else '_')
    return ''.join(keep) or 'test_map'

def save_timed_route(map_id: str, left_seconds=2.0, right_seconds=2.0, attack_times=1, window_title='MapleStory Worlds-楓星') -> Path:
    map_id = _safe_map_id(map_id)
    data = {
        'version': 'v15.3-waypoint-route-system',
        'map_id': str(map_id),
        'mode': 'timed_fallback',
        'loop': True,
        'window_title': window_title,
        'timed_route': [
            {'key': 'left', 'seconds': float(left_seconds), 'attack_times': int(attack_times)},
            {'key': 'right', 'seconds': float(right_seconds), 'attack_times': int(attack_times)},
        ],
        'combat': {'attack_key': 'ctrl', 'attack_interval': 0.12}
    }
    SCRIPTS.mkdir(exist_ok=True)
    path = SCRIPTS / f'{map_id}.yaml'
    with path.open('w', encoding='utf-8') as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
    return path

def clean_waypoints(points: List[Tuple[int, int]], min_distance: float = 6.0, max_jump: float = 160.0) -> List[List[int]]:
    out: List[List[int]] = []
    last = None
    for p in points:
        if p is None:
            continue
        x, y = int(p[0]), int(p[1])
        if last is None:
            out.append([x, y]); last = (x, y); continue
        dx = x - last[0]; dy = y - last[1]
        dist = (dx * dx + dy * dy) ** 0.5
        if dist < float(min_distance):
            continue
        # Ignore one-frame jumps caused by a wrong marker candidate.
        if dist > float(max_jump):
            continue
        out.append([x, y]); last = (x, y)
    return out

def save_waypoint_route(
    map_id: str,
    waypoints: List[Tuple[int, int]] | List[List[int]],
    *,
    window_title: str = 'MapleStory Worlds-楓星',
    minimap_rect: str = '0,0,245,251',
    route_mode: str = 'loop',
    inner_margin: int = 4,
    attack_key: str = 'ctrl',
    attack_times: int = 1,
    attack_interval: float = 0.12,
    waypoint_tolerance: int = 8,
    x_tolerance: int = 7,
    y_tolerance: int = 12,
) -> Path:
    map_id = _safe_map_id(map_id)
    pts = [[int(p[0]), int(p[1])] for p in (waypoints or [])]
    data = {
        'version': 'v15.3-waypoint-route-system',
        'map_id': str(map_id),
        'mode': 'waypoint_route',
        'loop': True,
        'window_title': window_title,
        'capture': {
            'minimap_rect': minimap_rect,
            'inner_margin': int(inner_margin),
            'title_bar_height': 0,
        },
        'route': {
            'route_mode': route_mode,
            'waypoint_tolerance': int(waypoint_tolerance),
            'x_tolerance': int(x_tolerance),
            'y_tolerance': int(y_tolerance),
            'move_step_seconds': 0.18,
            'max_stuck_seconds': 3.0,
            'stuck_nudge_seconds': 0.18,
        },
        'combat': {
            'attack_key': attack_key,
            'attack_times': int(attack_times),
            'attack_interval': float(attack_interval),
            'attack_every_waypoint': True,
            'attack_while_moving': False,
        },
        'waypoints': pts,
    }
    SCRIPTS.mkdir(exist_ok=True)
    path = SCRIPTS / f'{map_id}.yaml'
    with path.open('w', encoding='utf-8') as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
    return path

def load_script(path: str | Path) -> dict:
    p = Path(path)
    if not p.is_absolute():
        p = ROOT / p
    with p.open('r', encoding='utf-8') as f:
        return yaml.safe_load(f) or {}
