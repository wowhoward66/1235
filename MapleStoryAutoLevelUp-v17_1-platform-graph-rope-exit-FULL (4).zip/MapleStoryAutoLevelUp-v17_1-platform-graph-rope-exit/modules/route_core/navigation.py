from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple


def _pos(a: Any) -> Optional[Tuple[int, int]]:
    if not a or not isinstance(a, (list, tuple)) or len(a) < 2:
        return None
    try:
        return (int(round(float(a[0]))), int(round(float(a[1]))))
    except Exception:
        return None


def same_floor(a: Any, b: Any, threshold: int = 44) -> bool:
    pa, pb = _pos(a), _pos(b)
    if not pa or not pb:
        return False
    return abs(pa[1] - pb[1]) <= int(threshold)


def floor_distance(a: Any, b: Any) -> int:
    pa, pb = _pos(a), _pos(b)
    if not pa or not pb:
        return 999999
    return abs(pa[1] - pb[1])


def xy_distance(a: Any, b: Any) -> float:
    pa, pb = _pos(a), _pos(b)
    if not pa or not pb:
        return 999999.0
    return ((pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2) ** 0.5


def _action_allowed_for_nav(a: Dict[str, Any]) -> bool:
    """Actions that are safe entry points after navigation jumps.

    v16.9: do NOT jump into cross-floor replay-only transition bodies. Prefer stable anchors:
    - wait/floor_settle nodes
    - normal same-floor movement actions with a valid start_pos
    """
    mode = str(a.get('correction_mode') or 'auto')
    state = str(a.get('route_state') or '')
    if a.get('floor_transition') or mode == 'replay_only':
        return False
    if state in {'fall_transition', 'drop_transition', 'up_floor_transition', 'jump_up_transition', 'climb_transition'}:
        return False
    return bool(a.get('start_pos'))


def find_same_floor_entry(
    actions: List[Dict[str, Any]],
    current_index: int,
    current_pos: Any,
    *,
    floor_threshold: int = 44,
    lookahead: int = 12,
    lookbehind: int = 0,
    allow_wrap: bool = False,
    forbidden: Optional[set[int]] = None,
) -> Optional[int]:
    """Find a nearby same-floor action to continue from.

    v16.9 Navigation Lock fix:
    - default is NO wraparound search. v16.8 could jump from #20 back to #6, creating
      #6 -> #12 -> #19 -> #6 infinite loops.
    - previously visited jump targets can be forbidden by the runner.
    """
    cur = _pos(current_pos)
    if not cur:
        return None
    n = len(actions)
    forbidden = forbidden or set()
    candidates: List[Tuple[float, int]] = []

    max_forward = max(0, int(lookahead))
    for offset in range(0, max_forward + 1):
        raw_idx = current_index + offset
        if raw_idx >= n:
            if not allow_wrap:
                break
            idx = raw_idx % n
        else:
            idx = raw_idx
        if idx in forbidden:
            continue
        a = actions[idx]
        sp = _pos(a.get('start_pos'))
        if sp and _action_allowed_for_nav(a) and same_floor(cur, sp, floor_threshold):
            score = offset * 12.0 + abs(cur[0] - sp[0]) + abs(cur[1] - sp[1]) * 0.25
            candidates.append((score, idx))

    # Tiny lookbehind only, never wrapping. Useful when replay overshoots one small action.
    for offset in range(1, max(0, int(lookbehind)) + 1):
        idx = current_index - offset
        if idx < 0:
            break
        if idx in forbidden:
            continue
        a = actions[idx]
        sp = _pos(a.get('start_pos'))
        if sp and _action_allowed_for_nav(a) and same_floor(cur, sp, floor_threshold):
            score = 1000.0 + offset * 12.0 + abs(cur[0] - sp[0]) + abs(cur[1] - sp[1]) * 0.25
            candidates.append((score, idx))

    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0])
    return candidates[0][1]


def should_abort_for_floor_mismatch(now: Any, target: Any, action: Dict[str, Any], *, floor_threshold: int = 44) -> bool:
    """Return True when executing the action would likely cause wall bumps/jump spam."""
    if not now or not target:
        return False
    if same_floor(now, target, floor_threshold):
        return False
    mode = str(action.get('correction_mode') or 'auto')
    state = str(action.get('route_state') or '')
    # Explicit transitions are allowed to cross floors; navigation should not abort those.
    if action.get('floor_transition') or mode == 'replay_only':
        return False
    if state in {'fall_transition', 'drop_transition', 'up_floor_transition', 'jump_up_transition', 'climb_transition'}:
        return False
    return True
