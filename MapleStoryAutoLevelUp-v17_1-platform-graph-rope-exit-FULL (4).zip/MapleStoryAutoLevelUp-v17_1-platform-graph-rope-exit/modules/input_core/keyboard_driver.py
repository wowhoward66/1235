from __future__ import annotations
import time

_HELD = set()

def _keyboard():
    try:
        import keyboard
        return keyboard
    except Exception:
        return None

def key_down(key: str):
    key = str(key)
    kb = _keyboard()
    if kb:
        kb.press(key)
    else:
        import pyautogui
        pyautogui.keyDown(key)
    _HELD.add(key)

def key_up(key: str):
    key = str(key)
    kb = _keyboard()
    if kb:
        kb.release(key)
    else:
        import pyautogui
        pyautogui.keyUp(key)
    _HELD.discard(key)

def release_all():
    for k in list(_HELD):
        try:
            key_up(k)
        except Exception:
            pass

def press(key: str, duration: float = 0.05):
    try:
        key_down(key); time.sleep(max(0.01, float(duration))); key_up(key)
    finally:
        try: key_up(key)
        except Exception: pass

def hold(key: str, seconds: float):
    try:
        key_down(key); time.sleep(max(0.01, float(seconds))); key_up(key)
    finally:
        try: key_up(key)
        except Exception: pass

def combo(keys, seconds: float):
    keys = [str(k) for k in (keys or []) if str(k)]
    try:
        for k in keys:
            key_down(k)
        time.sleep(max(0.01, float(seconds)))
    finally:
        for k in reversed(keys):
            try: key_up(k)
            except Exception: pass
