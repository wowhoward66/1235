from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict, Any, List
import cv2
import numpy as np

@dataclass
class DetectionResult:
    ok: bool
    position: Optional[Tuple[float, float]] = None
    position_int: Optional[Tuple[int, int]] = None
    area: float = 0.0
    reason: str = ''
    mask: object = None
    overlay: object = None
    profile: str = ''
    debug: Dict[str, Any] = field(default_factory=dict)

DEFAULT_PROFILES = [
    ("yellow_wide", (10,45,70), (50,255,255)),
    ("yellow_bright", (12,35,110), (48,255,255)),
    ("amber_orange", (4,50,70), (32,255,255)),
    ("pale_yellow", (15,20,130), (60,180,255)),
    ("green_yellow", (35,35,80), (75,255,255)),
]

def shrink_rect_image(img, margin:int=0):
    if margin <= 0 or img is None or getattr(img, 'size', 0) == 0:
        return img, (0,0)
    h,w = img.shape[:2]
    if w <= margin*2+4 or h <= margin*2+4:
        return img, (0,0)
    return img[margin:h-margin, margin:w-margin], (margin, margin)

def _find_candidates(mask, min_area, max_area):
    kernel = np.ones((2,2), np.uint8)
    work = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    work = cv2.dilate(work, kernel, iterations=1)
    contours, _ = cv2.findContours(work, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates = []
    for c in contours:
        area = float(cv2.contourArea(c))
        if min_area <= area <= max_area:
            M = cv2.moments(c)
            if M.get('m00'):
                cxf = float(M['m10']/M['m00']); cyf = float(M['m01']/M['m00'])
                cx = int(round(cxf)); cy = int(round(cyf))
                x,y,w,h = cv2.boundingRect(c)
                if w <= 28 and h <= 28:
                    candidates.append({'area':area,'cx':cx,'cy':cy,'cxf':cxf,'cyf':cyf,'rect':(x,y,w,h),'contour':c})
    return candidates, contours, work

def detect_player_marker(minimap_bgr, hsv_lower=(12,60,80), hsv_upper=(45,255,255), min_area=1, max_area=450, inner_margin:int=4, profiles:Optional[List]=None) -> DetectionResult:
    if minimap_bgr is None or getattr(minimap_bgr, 'size', 0) == 0:
        return DetectionResult(False, reason='empty minimap')
    src, (ox,oy) = shrink_rect_image(minimap_bgr, inner_margin)
    hsv = cv2.cvtColor(src, cv2.COLOR_BGR2HSV)
    all_profiles = [('custom', tuple(hsv_lower), tuple(hsv_upper))] + (profiles if profiles is not None else DEFAULT_PROFILES)
    overlay = minimap_bgr.copy(); best=None; best_mask=None; debug=[]
    for name, lo, hi in all_profiles:
        mask0 = cv2.inRange(hsv, np.array(lo,dtype=np.uint8), np.array(hi,dtype=np.uint8))
        candidates, contours, mask = _find_candidates(mask0, min_area, max_area)
        debug.append({'profile':name,'lower':lo,'upper':hi,'mask_pixels':int(cv2.countNonZero(mask0)),'contours':len(contours),'candidates':len(candidates)})
        if candidates:
            h,w = src.shape[:2]
            def score(c):
                dist = abs(c['cx']-w/2)+abs(c['cy']-h/2)
                return c['area']*8 - dist*0.05
            cand = sorted(candidates, key=score, reverse=True)[0]
            s = score(cand)
            if best is None or s > best[0]:
                best=(s,name,cand); best_mask=mask
    if best is None:
        combined=np.zeros(hsv.shape[:2], dtype=np.uint8)
        for _,lo,hi in all_profiles:
            combined=cv2.bitwise_or(combined, cv2.inRange(hsv,np.array(lo,dtype=np.uint8),np.array(hi,dtype=np.uint8)))
        combined=cv2.dilate(combined,np.ones((2,2),np.uint8),iterations=1)
        full=np.zeros(minimap_bgr.shape[:2], dtype=np.uint8)
        full[oy:oy+combined.shape[0], ox:ox+combined.shape[1]]=combined
        return DetectionResult(False, reason=f'no marker candidate; profiles={len(all_profiles)}; combined_pixels={int(cv2.countNonZero(combined))}', mask=full, overlay=overlay, debug={'profiles':debug,'inner_margin':inner_margin})
    _, profile, cand = best
    cxf, cyf = float(cand.get('cxf', cand['cx'])) + ox, float(cand.get('cyf', cand['cy'])) + oy
    cx, cy = int(round(cxf)), int(round(cyf))
    x,y,w,h = cand['rect']; x+=ox; y+=oy
    cv2.rectangle(overlay,(x,y),(x+w,y+h),(0,255,255),1)
    cv2.circle(overlay,(cx,cy),8,(0,0,255),2)
    cv2.putText(overlay,profile,(max(0,cx-35),max(12,cy-12)),cv2.FONT_HERSHEY_SIMPLEX,0.35,(0,0,255),1)
    full=np.zeros(minimap_bgr.shape[:2], dtype=np.uint8)
    if best_mask is not None:
        full[oy:oy+best_mask.shape[0], ox:ox+best_mask.shape[1]]=best_mask
    return DetectionResult(True,(cxf,cyf),(cx,cy),float(cand['area']),'ok',full,overlay,profile,{'profiles':debug,'inner_margin':inner_margin,'rect':(x,y,w,h),'position_float':(cxf,cyf),'position_int':(cx,cy)})
