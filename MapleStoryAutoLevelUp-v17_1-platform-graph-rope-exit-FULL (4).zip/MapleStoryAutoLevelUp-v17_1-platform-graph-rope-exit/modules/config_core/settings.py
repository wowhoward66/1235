from __future__ import annotations
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG = ROOT / 'config' / 'config_default.yaml'
CUSTOM_CONFIG = ROOT / 'config' / 'config_custom.yaml'

def load_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open('r', encoding='utf-8') as f:
        data = yaml.safe_load(f) or {}
    return data if isinstance(data, dict) else {}

def save_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)

def load_config() -> dict:
    cfg = load_yaml(DEFAULT_CONFIG)
    cfg.update(load_yaml(CUSTOM_CONFIG))
    return cfg

def save_custom(updates: dict) -> None:
    cfg = load_yaml(CUSTOM_CONFIG)
    cfg.update(updates)
    save_yaml(CUSTOM_CONFIG, cfg)
