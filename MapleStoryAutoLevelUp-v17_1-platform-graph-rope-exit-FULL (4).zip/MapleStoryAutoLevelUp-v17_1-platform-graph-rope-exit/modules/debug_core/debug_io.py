from __future__ import annotations
from pathlib import Path
from datetime import datetime
import cv2

ROOT = Path(__file__).resolve().parents[2]
DEBUG_DIR = ROOT / 'debug'
DEBUG_DIR.mkdir(exist_ok=True)

def log(msg: str) -> None:
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    with (DEBUG_DIR / 'v15_status.log').open('a', encoding='utf-8') as f:
        f.write(line + '\n')

def save_image(name: str, image) -> Path:
    DEBUG_DIR.mkdir(exist_ok=True)
    path = DEBUG_DIR / name
    cv2.imwrite(str(path), image)
    log(f"Saved image: {path}")
    return path

def write_status(name: str, text: str) -> Path:
    DEBUG_DIR.mkdir(exist_ok=True)
    path = DEBUG_DIR / name
    path.write_text(text, encoding='utf-8')
    log(f"Saved status: {path}")
    return path
