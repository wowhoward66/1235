from __future__ import annotations
import os, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DEBUG = ROOT / 'debug'

class ProcessLock:
    """Small cross-process lock to prevent duplicated recorders/runners from GUI double clicks."""
    def __init__(self, name: str, stale_seconds: float = 600.0):
        DEBUG.mkdir(exist_ok=True)
        safe = ''.join(ch if ch.isalnum() or ch in '_-' else '_' for ch in name)
        self.path = DEBUG / f'{safe}.lock'
        self.stale_seconds = stale_seconds
        self.fd = None

    def acquire(self) -> bool:
        if self.path.exists():
            try:
                age = time.time() - self.path.stat().st_mtime
                if age > self.stale_seconds:
                    self.path.unlink(missing_ok=True)
            except Exception:
                pass
        try:
            self.fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(self.fd, f'pid={os.getpid()}\ntime={time.time()}\n'.encode('utf-8'))
            return True
        except FileExistsError:
            return False

    def release(self) -> None:
        try:
            if self.fd is not None:
                os.close(self.fd)
                self.fd = None
        finally:
            try:
                self.path.unlink(missing_ok=True)
            except Exception:
                pass

    def __enter__(self):
        if not self.acquire():
            raise RuntimeError(f'Another process is already running: {self.path}')
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release()
