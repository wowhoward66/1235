from __future__ import annotations
import time
from modules.input_core.keyboard_driver import press

def attack(attack_key='ctrl', times=1, interval=0.12):
    for _ in range(max(0, int(times))):
        press(attack_key, 0.04)
        time.sleep(float(interval))
