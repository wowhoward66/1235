from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import numpy as np

@dataclass
class WindowInfo:
    title: str
    rect: Tuple[int, int, int, int]
    hwnd: int = 0
    visible: bool = True
    iconic: bool = False
    area: int = 0
    usable: bool = True
    reason: str = ""

class CaptureError(RuntimeError):
    pass

def _rect_area(rect: Tuple[int,int,int,int]) -> int:
    l,t,r,b = rect
    return max(0, r-l) * max(0, b-t)

def _classify_window(rect, visible=True, iconic=False):
    l,t,r,b = rect
    w=max(0,r-l); h=max(0,b-t); area=w*h
    if iconic:
        return False, "minimized/iconic"
    if l <= -30000 or t <= -30000:
        return False, "offscreen/minimized rect"
    if not visible:
        return False, "not visible"
    if w < 400 or h < 300:
        return False, f"too small {w}x{h}"
    return True, ""

def _find_windows_win32(title_token: str) -> List[WindowInfo]:
    try:
        import win32gui
    except Exception:
        return []
    wins: List[WindowInfo] = []
    token = (title_token or "").lower()
    def cb(hwnd, _):
        try:
            title = win32gui.GetWindowText(hwnd) or ""
            if token and token not in title.lower():
                return
            visible = bool(win32gui.IsWindowVisible(hwnd))
            iconic = bool(win32gui.IsIconic(hwnd))
            rect = tuple(int(v) for v in win32gui.GetWindowRect(hwnd))
            usable, reason = _classify_window(rect, visible=visible, iconic=iconic)
            wins.append(WindowInfo(title=title, rect=rect, hwnd=int(hwnd), visible=visible,
                                   iconic=iconic, area=_rect_area(rect), usable=usable, reason=reason))
        except Exception:
            return
    win32gui.EnumWindows(cb, None)
    return wins

def list_game_windows(title_token: str) -> List[WindowInfo]:
    return _find_windows_win32(title_token)

def find_game_window(title_token: str, allow_unusable: bool = False) -> WindowInfo:
    wins = _find_windows_win32(title_token)
    if not wins:
        raise CaptureError(f"Game window not found by token: {title_token}")
    usable = [w for w in wins if w.usable]
    if usable:
        # Prefer the largest normal visible game window. This avoids selecting stale/minimized windows at -32000.
        usable.sort(key=lambda w: w.area, reverse=True)
        return usable[0]
    wins.sort(key=lambda w: w.area, reverse=True)
    if allow_unusable:
        return wins[0]
    detail = "; ".join([f"title={w.title!r} rect={w.rect} reason={w.reason}" for w in wins[:5]])
    raise CaptureError("No usable game window found. Restore/unminimize the MapleStory window, then run check again. " + detail)

def capture_window(title_token: str, title_bar_height: int = 0):
    from PIL import ImageGrab
    win = find_game_window(title_token)
    l, t, r, b = win.rect
    t = t + int(title_bar_height or 0)
    if r <= l or b <= t:
        raise CaptureError(f"Invalid window rect: {win.rect}")
    if (r-l) < 400 or (b-t) < 300:
        raise CaptureError(f"Captured window is too small: rect={win.rect}. The game may be minimized or the wrong window was selected.")
    img = ImageGrab.grab(bbox=(l, t, r, b))
    arr = np.array(img)
    if arr.ndim != 3 or arr.shape[0] < 300 or arr.shape[1] < 400:
        raise CaptureError(f"Invalid capture shape={getattr(arr, 'shape', None)} from rect={win.rect}")
    return arr[:, :, ::-1].copy(), win

def crop_rect(frame, rect: Tuple[int, int, int, int]):
    x, y, w, h = [int(v) for v in rect]
    H, W = frame.shape[:2]
    if H < 300 or W < 400:
        raise CaptureError(f"Frame too small for minimap crop: frame_shape={frame.shape}. Restore the game window first.")
    x = max(0, min(x, W-1)); y = max(0, min(y, H-1))
    w = max(1, min(w, W-x)); h = max(1, min(h, H-y))
    return frame[y:y+h, x:x+w].copy()
