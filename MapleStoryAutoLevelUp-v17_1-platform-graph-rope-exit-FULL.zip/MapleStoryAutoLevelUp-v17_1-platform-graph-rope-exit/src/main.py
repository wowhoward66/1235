from __future__ import annotations
import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QLabel, QLineEdit, QTabWidget, QDoubleSpinBox, QSpinBox
from PySide6.QtCore import QProcess

ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable

class V17Gui(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('MapleStoryAutoLevelUp v17.1 Platform Graph + Rope Exit State')
        self.resize(1000, 720)
        self.procs = []
        self.active_modules = {}
        main = QVBoxLayout(self)
        self.tabs = QTabWidget(); main.addWidget(self.tabs)
        self.log = QTextEdit(); self.log.setReadOnly(True); main.addWidget(self.log, 1)
        self._build_system_tab(); self._build_intent_route_tab(); self._build_smart_route_tab(); self._build_run_tab()

    def add_line(self, s):
        self.log.append(str(s))

    def run_module(self, module, args=None):
        args = args or []
        singleton = module in {'tools.action_route_recorder', 'tools.route_intent_recorder', 'tools.run_script'}
        if singleton:
            for m, proc in list(self.active_modules.items()):
                if proc.state() != QProcess.NotRunning and (m == module or module == 'tools.run_script' or m == 'tools.run_script'):
                    self.add_line(f'SKIP: {module} already has an active helper running: {m}. Press Stop All first if needed.')
                    return
        cmd = [PYTHON, '-m', module] + args
        self.add_line('RUN: ' + ' '.join(cmd))
        p = QProcess(self)
        p.setWorkingDirectory(str(ROOT))
        p.readyReadStandardOutput.connect(lambda p=p: self.add_line(bytes(p.readAllStandardOutput()).decode('utf-8','replace')))
        p.readyReadStandardError.connect(lambda p=p: self.add_line(bytes(p.readAllStandardError()).decode('utf-8','replace')))
        def _finished(code, status, p=p, module=module):
            self.add_line(f'FINISHED {module}: code={code}')
            if self.active_modules.get(module) is p:
                self.active_modules.pop(module, None)
        p.finished.connect(_finished)
        p.start(cmd[0], cmd[1:])
        self.procs.append(p)
        if singleton:
            self.active_modules[module] = p

    def _build_system_tab(self):
        tab = QWidget(); lay = QVBoxLayout(tab)
        self.win_title = QLineEdit('MapleStory Worlds-楓星')
        self.rect = QLineEdit('0,0,245,251')
        self.inner_margin = QSpinBox(); self.inner_margin.setRange(0, 30); self.inner_margin.setValue(4)
        lay.addWidget(QLabel('Window title token')); lay.addWidget(self.win_title)
        lay.addWidget(QLabel('Minimap rect: x,y,w,h')); lay.addWidget(self.rect)
        lay.addWidget(QLabel('Inner margin')); lay.addWidget(self.inner_margin)
        row = QHBoxLayout()
        for text, mod, extra in [
            ('System Check', 'tools.system_check', []),
            ('Window Check', 'tools.window_check', ['--window_title', self.win_title.text]),
            ('Capture Check', 'tools.capture_check', ['--window_title', self.win_title.text, '--minimap_rect', self.rect.text]),
            ('Minimap Player Check', 'tools.minimap_check', ['--window_title', self.win_title.text, '--minimap_rect', self.rect.text, '--inner_margin', lambda: str(self.inner_margin.value())]),
        ]:
            btn = QPushButton(text)
            def make_cb(mod=mod, extra=extra):
                def cb():
                    args=[]
                    for x in extra:
                        args.append(x() if callable(x) else x)
                    self.run_module(mod, args)
                return cb
            btn.clicked.connect(make_cb())
            row.addWidget(btn)
        lay.addLayout(row)
        lay.addWidget(QLabel('先確認 minimap_check ok=True，再錄 Smart Route。'))
        self.tabs.addTab(tab, 'System / Minimap')

    def _build_smart_route_tab(self):
        tab = QWidget(); lay = QVBoxLayout(tab)
        self.map_id = QLineEdit('test_map')
        self.action_max_seconds = QDoubleSpinBox(); self.action_max_seconds.setRange(5.0, 600.0); self.action_max_seconds.setValue(180.0)
        self.playback_speed = QDoubleSpinBox(); self.playback_speed.setRange(0.25, 3.0); self.playback_speed.setSingleStep(0.05); self.playback_speed.setValue(1.0)
        self.pos_sample = QDoubleSpinBox(); self.pos_sample.setRange(0.1, 2.0); self.pos_sample.setSingleStep(0.05); self.pos_sample.setValue(0.25)
        self.allowed_keys = QLineEdit('left,right,up,down,alt,ctrl,space,shift,z,x,c,a,s,d,f,1,2,3,4,5,6,q,w,e,r')
        lay.addWidget(QLabel('Map ID')); lay.addWidget(self.map_id)
        lay.addWidget(QLabel('Max record seconds')); lay.addWidget(self.action_max_seconds)
        lay.addWidget(QLabel('Playback speed')); lay.addWidget(self.playback_speed)
        lay.addWidget(QLabel('Position sample interval')); lay.addWidget(self.pos_sample)
        lay.addWidget(QLabel('Allowed keys to record')); lay.addWidget(self.allowed_keys)
        row = QHBoxLayout()
        rec = QPushButton('Start Smart Route Recorder')
        rec.clicked.connect(lambda: self.run_module('tools.action_route_recorder', [
            '--map_id', self.map_id.text(), '--window_title', self.win_title.text(), '--minimap_rect', self.rect.text(),
            '--inner_margin', str(self.inner_margin.value()), '--max_seconds', str(self.action_max_seconds.value()),
            '--playback_speed', str(self.playback_speed.value()), '--position_sample_interval', str(self.pos_sample.value()),
            '--allowed_keys', self.allowed_keys.text()
        ]))
        chk = QPushButton('Check Smart Route')
        chk.clicked.connect(lambda: self.run_module('tools.smart_route_check', ['--script', self.script_path.text()]))
        row.addWidget(rec); row.addWidget(chk); lay.addLayout(row)
        lay.addWidget(QLabel('錄一整圈：走路、跳台、爬繩、下跳、攻擊。F12 停止保存。v16 會把動作和 minimap 座標一起存成 smart_action_route。'))
        self.tabs.addTab(tab, 'Smart Route')


    def _build_intent_route_tab(self):
        tab = QWidget(); lay = QVBoxLayout(tab)
        self.intent_stable_seconds = QDoubleSpinBox(); self.intent_stable_seconds.setRange(0.5, 5.0); self.intent_stable_seconds.setSingleStep(0.1); self.intent_stable_seconds.setValue(1.5)
        self.intent_commit_seconds = QDoubleSpinBox(); self.intent_commit_seconds.setRange(0.5, 6.0); self.intent_commit_seconds.setSingleStep(0.1); self.intent_commit_seconds.setValue(2.0)
        self.intent_sample_interval = QDoubleSpinBox(); self.intent_sample_interval.setRange(0.08, 0.6); self.intent_sample_interval.setSingleStep(0.02); self.intent_sample_interval.setValue(0.18)
        lay.addWidget(QLabel('v17.1 Route Intent：只學有效平台/繩索/轉場；新增 Rope Exit State，不再亂跳找繩。'))
        lay.addWidget(QLabel('Stable platform seconds（停留多久才算平台）')); lay.addWidget(self.intent_stable_seconds)
        lay.addWidget(QLabel('Transition commit seconds（換層後穩定多久才保留）')); lay.addWidget(self.intent_commit_seconds)
        lay.addWidget(QLabel('Position sample interval')); lay.addWidget(self.intent_sample_interval)
        row = QHBoxLayout()
        rec = QPushButton('Start Route Intent Recorder')
        rec.clicked.connect(lambda: self.run_module('tools.route_intent_recorder', [
            '--map_id', self.map_id.text(), '--window_title', self.win_title.text(), '--minimap_rect', self.rect.text(),
            '--inner_margin', str(self.inner_margin.value()), '--max_seconds', str(self.action_max_seconds.value()),
            '--sample_interval', str(self.intent_sample_interval.value()), '--stable_seconds', str(self.intent_stable_seconds.value()),
            '--commit_seconds', str(self.intent_commit_seconds.value())
        ]))
        chk = QPushButton('Check Route Intent')
        chk.clicked.connect(lambda: self.run_module('tools.route_intent_check', ['--script', self.script_path.text()]))
        row.addWidget(rec); row.addWidget(chk); lay.addLayout(row)
        lay.addWidget(QLabel('錄製方式：走一圈真正要刷的路線；進平台後停 1.5 秒；爬繩到頂後也停一下，讓系統學到平台。F12 停止。'))
        self.tabs.addTab(tab, 'Route Intent v17')

    def _build_run_tab(self):
        tab = QWidget(); lay = QVBoxLayout(tab)
        self.script_path = QLineEdit('scripts/test_map.yaml')
        lay.addWidget(QLabel('Script path')); lay.addWidget(self.script_path)
        row = QHBoxLayout()
        run = QPushButton('Run Smart Bot')
        run.clicked.connect(lambda: self.run_module('tools.run_script', ['--script', self.script_path.text()]))
        stop = QPushButton('Stop All Child Processes')
        stop.clicked.connect(self.stop_all)
        row.addWidget(run); row.addWidget(stop); lay.addLayout(row)
        lay.addWidget(QLabel('v17.1：建議使用 Route Intent v17 錄製。Run 會支援 route_intent / smart_action_route。'))
        self.tabs.addTab(tab, 'Run')

    def stop_all(self):
        for p in self.procs:
            if p.state() != QProcess.NotRunning:
                p.terminate()
                if not p.waitForFinished(800):
                    p.kill()
        self.active_modules.clear()
        self.add_line('Stop requested for all child processes.')


def main():
    app = QApplication(sys.argv)
    w = V17Gui(); w.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
