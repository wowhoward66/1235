from __future__ import annotations
import time
from typing import Any, Dict, List, Optional, Tuple

from modules.route_core.smart_action import current_position
from modules.input_core.keyboard_driver import hold, press, combo, release_all
from modules.debug_core.debug_io import log, write_status

Point = Tuple[float, float]
_LAST_VALID_POS: Optional[Point] = None



def _dist(a: Optional[Point], b: Optional[Point]) -> float:
    if not a or not b:
        return 999999.0
    return ((float(a[0]) - float(b[0])) ** 2 + (float(a[1]) - float(b[1])) ** 2) ** 0.5


def _median(vals: List[float]) -> float:
    if not vals:
        return 0.0
    vals = sorted(vals)
    return vals[len(vals) // 2]


def _center(platform: Dict[str, Any]) -> Point:
    xr = platform.get('x_range') or [platform.get('x', 0), platform.get('x', 0)]
    return ((float(xr[0]) + float(xr[1])) / 2.0, float(platform.get('y', 0)))


def _same_floor(a: Point, platform: Dict[str, Any], tol: float) -> bool:
    return abs(float(a[1]) - float(platform.get('y', 0))) <= float(tol)


def _platform_contains_x(platform: Dict[str, Any], x: float, margin: float = 8.0) -> bool:
    xr = platform.get('x_range') or [platform.get('x', 0), platform.get('x', 0)]
    return float(xr[0]) - margin <= float(x) <= float(xr[1]) + margin


def _nearest_platform(platforms: List[Dict[str, Any]], pos: Point, floor_tol: float = 18.0) -> Optional[Dict[str, Any]]:
    same = [p for p in platforms if _same_floor(pos, p, floor_tol)]
    if not same:
        return None
    same.sort(key=lambda p: 0 if _platform_contains_x(p, pos[0]) else abs(pos[0] - _center(p)[0]))
    return same[0]


def _read_pos(window_title: str, minimap_rect: str, inner_margin: int, *, reject_jump: bool = True) -> Optional[Point]:
    """Read minimap position with a conservative false-marker filter.

    The detector can occasionally lock onto a wrong yellow blob (for example x~=10).
    For normal control loops we reject impossible jumps from the last valid marker.
    Transition routines call this repeatedly after an intentional floor change, so the
    threshold is intentionally large enough to still allow real rope/drop movement.
    """
    global _LAST_VALID_POS
    pos, profile, reason = current_position(window_title, minimap_rect, inner_margin, precise=True)
    if not pos:
        return None
    p = (float(pos[0]), float(pos[1]))
    if reject_jump and _LAST_VALID_POS is not None:
        dx = abs(p[0] - _LAST_VALID_POS[0])
        dy = abs(p[1] - _LAST_VALID_POS[1])
        # During one frame, a marker should not teleport across the minimap unless a real
        # transition is in progress. Reject extreme outliers to avoid wrong platform state.
        if dx > 95 and dy < 70:
            log(f'[route_intent] discard false marker pos={p} last={_LAST_VALID_POS}')
            return _LAST_VALID_POS
    _LAST_VALID_POS = p
    return p


def _move_x_toward(target_x: float, current_x: float, seconds: float = 0.12, tol: float = 5.0):
    dx = float(target_x) - float(current_x)
    if abs(dx) <= tol:
        return
    hold('right' if dx > 0 else 'left', seconds)


def _controlled_walk_to_x(window_title: str, minimap_rect: str, inner_margin: int, target_x: float, *, timeout: float = 5.0, x_tol: float = 6.0, no_jump: bool = True) -> Dict[str, Any]:
    """Walk horizontally only. This is the core v17 rule: do not jump during correction."""
    t0 = time.time()
    last = None
    stuck_ticks = 0
    while time.time() - t0 < timeout:
        pos = _read_pos(window_title, minimap_rect, inner_margin)
        if not pos:
            time.sleep(0.12)
            continue
        dx = float(target_x) - pos[0]
        if abs(dx) <= x_tol:
            return {'ok': True, 'pos': pos, 'target_x': target_x, 'reason': 'x_aligned'}
        if last and abs(pos[0] - last[0]) <= 0.5 and abs(pos[1] - last[1]) <= 0.5:
            stuck_ticks += 1
        else:
            stuck_ticks = 0
        last = pos
        # If stuck, do NOT jump. Release briefly and retry walk.
        if stuck_ticks >= 10:
            release_all()
            time.sleep(0.18)
            stuck_ticks = 0
        _move_x_toward(target_x, pos[0], seconds=0.14, tol=x_tol)
    pos = _read_pos(window_title, minimap_rect, inner_margin)
    return {'ok': False, 'pos': pos, 'target_x': target_x, 'reason': 'walk_timeout'}


def _confirm_platform(window_title: str, minimap_rect: str, inner_margin: int, platform: Dict[str, Any], *, seconds: float = 1.0, floor_tol: float = 18.0) -> Dict[str, Any]:
    """Require repeated samples on the expected platform; avoids continuing while still falling/rope."""
    t0 = time.time()
    ok_count = 0
    total = 0
    last = None
    while time.time() - t0 < seconds:
        pos = _read_pos(window_title, minimap_rect, inner_margin)
        if pos:
            last = pos
            total += 1
            if _same_floor(pos, platform, floor_tol) and _platform_contains_x(platform, pos[0], margin=18):
                ok_count += 1
        time.sleep(0.12)
    ok = ok_count >= max(2, total // 2)
    return {'ok': ok, 'samples': total, 'ok_count': ok_count, 'last': last, 'platform': platform.get('id')}



def _rope_exit_state(window_title: str, minimap_rect: str, inner_margin: int, dst: Dict[str, Any], transition: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Leave rope/ladder at the top in a controlled way.

    Important rule: this is only called inside an intentional rope transition, not as
    a generic correction. It prevents the bot from randomly jumping to find ropes.
    """
    jump_key = str(cfg.get('keys', {}).get('jump', 'alt'))
    floor_tol = float(cfg.get('floor_confirm_tolerance', 18))
    exit_dirs = transition.get('exit_dirs') or cfg.get('rope_exit_dirs') or ['right', 'left']
    max_attempts = int(cfg.get('rope_exit_attempts', 2))
    y_gate = float(cfg.get('rope_exit_y_gate', 24))
    results = []
    for attempt in range(1, max_attempts + 1):
        pos = _read_pos(window_title, minimap_rect, inner_margin, reject_jump=False)
        near_top = bool(pos and abs(pos[1] - float(dst.get('y', pos[1]))) <= y_gate)
        release_all()
        time.sleep(0.12)
        if not near_top:
            # Not high enough yet: do not jump. Continue climbing a short controlled burst.
            hold('up', float(cfg.get('rope_topup_seconds', 0.45)))
            release_all()
            time.sleep(0.2)
        else:
            d = str(exit_dirs[(attempt - 1) % len(exit_dirs)])
            hold(d, float(cfg.get('rope_exit_nudge_seconds', 0.16)))
            # A single jump is allowed only here, after being near the top.
            press(jump_key, float(cfg.get('rope_exit_jump_seconds', 0.055)))
            time.sleep(float(cfg.get('rope_exit_settle_seconds', 0.45)))
        confirm = _confirm_platform(window_title, minimap_rect, inner_margin, dst, seconds=float(cfg.get('platform_confirm_seconds', 1.2)), floor_tol=floor_tol)
        results.append({'attempt': attempt, 'near_top': near_top, 'confirm': confirm})
        if confirm.get('ok'):
            return {'ok': True, 'attempts': results}
    return {'ok': False, 'attempts': results}

def _execute_transition(window_title: str, minimap_rect: str, inner_margin: int, transition: Dict[str, Any], dst: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Execute an intentional platform transition. Jumps/up/down happen only here."""
    ttype = str(transition.get('type') or '')
    x = float(transition.get('x') or _center(dst)[0])
    max_attempts = int(cfg.get('transition_max_attempts', 2))
    floor_tol = float(cfg.get('floor_confirm_tolerance', 18))
    jump_key = str(cfg.get('keys', {}).get('jump', 'alt'))
    results = []
    for attempt in range(1, max_attempts + 1):
        align = _controlled_walk_to_x(window_title, minimap_rect, inner_margin, x, timeout=float(cfg.get('align_timeout', 4.0)), x_tol=float(cfg.get('rope_x_tolerance', 7)))
        if ttype in {'rope_up', 'climb_up', 'up'}:
            # Controlled rope policy: align -> one optional entry jump -> hold up.
            # No repeated random jumping is allowed outside this transition node.
            if bool(transition.get('needs_jump', True)):
                combo(['up', jump_key], 0.18)
            hold('up', float(transition.get('duration') or cfg.get('rope_hold_seconds', 2.2)))
            release_all()
            # v17.1: once near the top, explicitly exit rope and confirm platform stability.
            exit_res = _rope_exit_state(window_title, minimap_rect, inner_margin, dst, transition, cfg)
            if exit_res.get('ok'):
                results.append({'attempt': attempt, 'align': align, 'rope_exit': exit_res})
                return {'ok': True, 'transition': transition.get('id'), 'attempts': results, 'reason': 'rope_exit_ok'}
        elif ttype in {'drop_down', 'fall_down', 'down'}:
            # One explicit down-jump at a marked drop node. No repeating spam.
            combo(['down', jump_key], float(transition.get('duration') or cfg.get('drop_combo_seconds', 0.18)))
        else:
            # Unknown transition: replay a conservative hint once.
            hint = transition.get('key_hint') or []
            if hint:
                combo([str(k) for k in hint], float(transition.get('duration') or 0.25))
            else:
                time.sleep(float(transition.get('duration') or 0.25))
        release_all()
        settle = float(cfg.get('transition_settle_seconds', 1.0))
        time.sleep(settle)
        confirm = _confirm_platform(window_title, minimap_rect, inner_margin, dst, seconds=float(cfg.get('platform_confirm_seconds', 1.2)), floor_tol=floor_tol)
        results.append({'attempt': attempt, 'align': align, 'confirm': confirm})
        if confirm.get('ok'):
            return {'ok': True, 'transition': transition.get('id'), 'attempts': results}
    return {'ok': False, 'transition': transition.get('id'), 'attempts': results}


def run_route_intent(script: Dict[str, Any], path: str):
    cfg = script.get('route_intent') or {}
    cfg.setdefault('rope_exit_attempts', 2)
    cfg.setdefault('rope_exit_y_gate', 24)
    cfg.setdefault('rope_topup_seconds', 0.45)
    cfg.setdefault('rope_exit_nudge_seconds', 0.16)
    cfg.setdefault('rope_exit_settle_seconds', 0.45)
    cfg.setdefault('platform_confirm_seconds', 1.2)
    cap = script.get('capture') or {}
    window_title = script.get('window_title', 'MapleStory Worlds-楓星')
    minimap_rect = cap.get('minimap_rect', '0,0,245,251')
    inner_margin = int(cap.get('inner_margin', 4))
    platforms: List[Dict[str, Any]] = script.get('platforms') or []
    transitions: List[Dict[str, Any]] = script.get('transitions') or []
    sequence: List[Dict[str, Any]] = script.get('sequence') or []
    loop = bool(script.get('loop', True))
    if not platforms or not sequence:
        raise RuntimeError('route_intent needs platforms and sequence. Record first with tools.route_intent_recorder.')
    p_by_id = {str(p.get('id')): p for p in platforms}
    t_by_id = {str(t.get('id')): t for t in transitions}
    log(f'Route Intent runner v17.1 rope-exit start: {path}; platforms={len(platforms)} transitions={len(transitions)} sequence={len(sequence)} loop={loop}')
    idx = 0
    try:
        while True:
            if idx >= len(sequence):
                if loop:
                    idx = 0
                else:
                    break
            step = sequence[idx]
            stype = str(step.get('type') or '')
            status: Dict[str, Any] = {'idx': idx + 1, 'total': len(sequence), 'step': step}
            if stype == 'platform':
                p = p_by_id.get(str(step.get('platform')))
                if not p:
                    idx += 1; continue
                current = _read_pos(window_title, minimap_rect, inner_margin)
                # Controlled correction: x-only, no jumps, no rope search.
                target_x = float(step.get('x') or _center(p)[0])
                if current and _same_floor(current, p, float(cfg.get('floor_confirm_tolerance', 18))):
                    walk = _controlled_walk_to_x(window_title, minimap_rect, inner_margin, target_x, timeout=float(cfg.get('walk_timeout', 5.0)), x_tol=float(cfg.get('walk_x_tolerance', 8.0)))
                    status['walk'] = walk
                confirm = _confirm_platform(window_title, minimap_rect, inner_margin, p, seconds=float(cfg.get('stable_confirm_seconds', 0.8)), floor_tol=float(cfg.get('floor_confirm_tolerance', 18)))
                status['confirm'] = confirm
                # Attack only after being on a stable platform.
                attack_key = str(cfg.get('attack_key', 'ctrl'))
                attack_times = int(cfg.get('attack_times_per_platform', 1))
                for _ in range(max(0, attack_times)):
                    press(attack_key, float(cfg.get('attack_press_seconds', 0.05)))
                    time.sleep(float(cfg.get('attack_interval', 0.12)))
            elif stype == 'transition':
                t = t_by_id.get(str(step.get('transition')))
                if not t:
                    idx += 1; continue
                dst = p_by_id.get(str(t.get('to')))
                if not dst:
                    idx += 1; continue
                res = _execute_transition(window_title, minimap_rect, inner_margin, t, dst, cfg)
                status['transition_result'] = res
                if not res.get('ok'):
                    # Do not search forever. Walk back to source platform if available, then continue/loop.
                    src = p_by_id.get(str(t.get('from')))
                    if src:
                        _controlled_walk_to_x(window_title, minimap_rect, inner_margin, _center(src)[0], timeout=2.0)
            else:
                time.sleep(float(step.get('duration') or 0.1))
            write_status('route_intent_runner_status.txt', '\n'.join(f'{k}={v}' for k, v in status.items()) + '\n')
            log(f'[route_intent] {status}')
            idx += 1
    except KeyboardInterrupt:
        log('Route Intent runner stopped by Ctrl+C')
    finally:
        release_all()
